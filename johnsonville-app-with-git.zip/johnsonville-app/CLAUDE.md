# CLAUDE.md

Guidance for Claude Code when working in this repository.

## What this is

A Progressive Web App for the Johnsonville Commissioner's Office (Liberia)
managing case/dispute filings, land records, community registry, revenue,
public works, communications, and meeting records. Built offline-first for
intermittent 2G/3G/4G and frequent power outages, for non-technical clerks
on low-end Android phones.

Full spec: none checked in separately — this codebase *is* the spec made
concrete. If behavior is ambiguous, prefer what's already implemented
elsewhere in the same module over inventing a new pattern.

## Repo layout

```
backend/     Node/Express API, TypeScript, Neo4j (AuraDB Free) as primary store
frontend/    React PWA (Vite), TypeScript, Dexie/IndexedDB offline queue
```

Backend entry: `backend/src/index.ts` (starts the server) wraps
`backend/src/app.ts` (the Express app factory — tests import this directly,
never `index.ts`, to avoid binding a port or running schema-ensure on boot).

Frontend entry: `frontend/src/main.tsx` → `App.tsx` (routing) →
`components/Layout.tsx` (role-gated nav) → per-module pages under
`frontend/src/pages/`.

## First thing to do in a fresh session

This project has never been built or run — it was generated without
network access. Before anything else:

```bash
cd backend && npm install && npm run build && npm test
cd ../frontend && npm install && npm run build && npm test
```

Fix whatever breaks (dependency version mismatches, ts-jest/vitest config
issues, type errors) before touching database/OAuth setup. Treat this as
the actual starting task, not a formality.

## Critical conventions — do not deviate from these

1. **Every primary node ID is a client-generated UUID**, not a
   server-assigned one (`case_id`, `parcel_id`, `person_id`, etc.). This is
   load-bearing: it's what lets a clerk create a Case *and* a new Person
   (the filer) while fully offline, in one form, and have both sync
   together correctly later without waiting on server round-trips. If you
   add a new entity type, give it a client-generatable UUID primary key
   too — see `frontend/src/db/offlineDb.ts` (`generateId`) and the
   `MERGE ... ON CREATE SET` pattern used in every backend route.

2. **Every node carries an audit trail**: `created_by`, `created_at`,
   `last_edited_by`, `last_edited_at`. Use `stampCreate()` / `stampEdit()`
   from `backend/src/utils/audit.ts` — don't set these fields by hand.

3. **AuraDB Free has real constraints** the code is built around — don't
   "fix" these away:
   - Auto-pauses after inactivity; `backend/src/config/neo4j.ts`
     (`runQuery`) retries with backoff on transient connection errors.
     Always query through `runQuery`, never open a raw driver session.
   - ~200K node / 400K relationship cap. `backend/src/routes/admin.ts`
     (`/db-usage`) surfaces this in the Admin panel — keep it working if
     you touch that route.
   - No managed backup. `backend/src/utils/backup.ts` is the mitigation —
     don't remove it.

4. **Offline sync is last-write-wins but never silent.** Conflicts create
   a `SyncConflict` node (`needs_review: true`) reviewed in
   Admin → Sync Conflicts. See `backend/src/routes/sync.ts` and
   `frontend/src/db/syncEngine.ts`. If you touch sync logic, keep both
   sides consistent — the frontend queue shape and the backend
   `SYNC_TARGETS` config must agree on entity types and editable fields.

5. **Role gating**: `Commissioner`, `Clerk`, `Official`, `SuperAdmin`.
   Backend: `requireRole()` in `backend/src/middleware/roles.ts`. Frontend:
   `hasRole()` in `frontend/src/auth/AuthContext.tsx`. Clerks get a
   simplified task view, not the full dashboard — don't collapse that
   distinction.

6. **Photos are compressed client-side before they ever touch IndexedDB or
   the network** — `frontend/src/utils/compressPhoto.ts`. Don't add a path
   that stores/syncs an uncompressed photo.

## Testing

```bash
cd backend && npm test     # Jest — mocks the Neo4j driver, no real DB needed
cd frontend && npm test    # Vitest — uses fake-indexeddb, no real DB needed
```

Tests are written to run without any real Neo4j/AuraDB/Google OAuth
credentials. If a test you're adding needs real credentials to pass,
that's a sign it should be mocking at a different layer.

## Local dev without real AuraDB/Google OAuth

- `docker compose --profile local-neo4j up --build` spins up a local Neo4j
  Community container. Point `backend/.env` at
  `NEO4J_URI=bolt://neo4j:7687` to use it instead of AuraDB during dev.
- Google OAuth still needs real credentials (client ID/secret) — there's
  no local stub for it. If you need to exercise authenticated routes
  without going through the real OAuth flow, sign a JWT by hand with the
  `JWT_SECRET` from `.env` and set it as the session cookie, matching the
  shape in `backend/src/middleware/auth.ts` (`AuthedUser`).

## Pushing to GitHub

A git repo already exists at the project root with one initial commit on
`main` (`.env` files are gitignored — check `git status` before pushing to
make sure nothing sensitive snuck in). If there's no `origin` remote yet:

```bash
gh auth status || gh auth login          # ensure gh CLI is authenticated
gh repo create johnsonville-commissioner-app --private --source=. --remote=origin
git push -u origin main
```

If the person doesn't have the `gh` CLI available, fall back to:

```bash
# after creating an empty repo at github.com/new (don't initialize it
# with a README/license — this repo already has content)
git remote add origin https://github.com/<their-username>/<repo-name>.git
git push -u origin main
```

After pushing, check that CI went green:

```bash
gh run list --limit 1
gh run watch          # or: open the Actions tab in the browser
```

If CI fails, that's expected on a first push if this is the first time
`npm install` has actually been run against these dependency versions —
treat CI failures here the same as the "first thing to do in a fresh
session" build/test pass above: fix what's broken, commit, push again.

## Definition of done for a change here

- `npm run build` and `npm test` pass in both `backend/` and `frontend/`.
- New Neo4j node types get a uniqueness constraint added in
  `backend/src/models/schema.ts`.
- New entities follow the client-generated-UUID + audit-stamp conventions
  above, and any offline-editable entity is added to `SYNC_TARGETS` in
  `backend/src/routes/sync.ts` and the `EntityType` union in
  `frontend/src/db/offlineDb.ts`.
- Docker images still build: `docker build ./backend` and
  `docker build ./frontend`.
