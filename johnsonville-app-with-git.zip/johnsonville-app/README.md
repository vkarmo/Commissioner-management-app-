# Johnsonville Commissioner's Office Management App

A Progressive Web App for district civic operations: case/dispute filings,
land records, community registry, revenue collection, public works
tracking, official communications, and community meeting records. Built
offline-first for intermittent 2G/3G/4G connectivity and frequent power
outages.

## Structure

```
backend/    Node/Express API + Neo4j (AuraDB Free) connection
frontend/   React PWA (Vite) with Dexie-based offline queue/sync
```

## 1. Set up Neo4j AuraDB Free

1. Create a free instance at https://console.neo4j.io.
2. Note the connection URI, username, and password shown at creation time
   (the password is only shown once).
3. AuraDB Free auto-pauses after inactivity and caps out around 200K nodes
   / 400K relationships. The backend is built to tolerate the wake-up
   delay (`src/config/neo4j.ts` retries with backoff) and the Admin panel
   shows a usage indicator so you'll see it coming before you hit the cap.
   Plan to upgrade to a paid Aura tier (or self-hosted Neo4j) before
   production go-live or as usage approaches the cap.

## 2. Set up Google OAuth

1. In the [Google Cloud Console](https://console.cloud.google.com),
   create an OAuth 2.0 Client ID (Web application).
2. Add `http://localhost:4000/api/auth/google/callback` as an authorized
   redirect URI for local dev (add your production callback URL too once
   deployed).
3. Note the client ID and client secret.

## 3. Backend setup

```bash
cd backend
cp .env.example .env
# fill in NEO4J_URI / NEO4J_USERNAME / NEO4J_PASSWORD,
# GOOGLE_CLIENT_ID / GOOGLE_CLIENT_SECRET, JWT_SECRET, BOOTSTRAP_SUPER_ADMINS
npm install
npm run seed     # creates schema constraints + sample Johnsonville data,
                  # and whitelists BOOTSTRAP_SUPER_ADMINS as Super Admin
npm run dev       # starts the API on :4000
```

Once you've signed in as the bootstrap Super Admin, use the in-app
**Admin → Manage Whitelist** screen to add the rest of the Commissioner's
staff — no further `.env` edits or redeploys needed.

## 4. Frontend setup

```bash
cd frontend
npm install
npm run dev       # starts the Vite dev server on :5173, proxies /api to :4000
```

Open http://localhost:5173 and sign in with a whitelisted Google account.

## 5. Scheduled backups

AuraDB Free has no managed backup. Run the export job on a schedule (cron,
systemd timer, etc.) and sync the output directory offsite:

```bash
cd backend
npm run backup    # writes a timestamped JSON dump to ./backups
```

Example crontab entry (daily at 2am, then sync offsite with rclone):

```
0 2 * * * cd /path/to/backend && npm run backup && rclone sync ./backups remote:jc-backups
```

## 6. Deployment

- **API**: deploy `backend/` to a small VPS or a Render/Railway-style host.
  Set the same env vars as `.env.example`, pointing `CLIENT_ORIGIN` at your
  deployed frontend URL and `GOOGLE_CALLBACK_URL` at your deployed API URL.
- **Frontend**: `npm run build` in `frontend/` produces a static bundle
  (`dist/`) installable as a PWA on Android home screens. Serve it from the
  same host as the API (behind a reverse proxy routing `/api` to Express)
  or from any static host, with CORS configured accordingly.

## 7. Parcel boundary map

When a parcel has GeoJSON geometry on file (entered via the "Boundary
geometry" field on **Register Parcel**, or synced in from a survey
pipeline later), its detail page renders a Leaflet map showing the parcel
outline plus any adjacent parcels that also have geometry, using
OpenStreetMap tiles. Parcels without geometry show a placeholder instead
of an empty/broken map. Base map tiles need connectivity to load; the
boundary shapes themselves render from cached parcel data even offline.

## 8. Running tests

```bash
cd backend && npm test    # Jest: audit trail stamps, schema constraints,
                           # health/auth gating, sync conflict detection,
                           # AuraDB Free retry/backoff behavior
cd frontend && npm test   # Vitest: offline write queue (Dexie), sync
                           # engine, sync status UI
```

CI (`.github/workflows/ci.yml`) runs both test suites plus a build check
for the backend and frontend Docker images on every push/PR to `main`.

## 9. Running with Docker

```bash
cp backend/.env.example backend/.env   # fill in real credentials first
docker compose up --build
```

This starts the backend API (`:4000`) and the frontend, served as a static
PWA build behind nginx (`:8080`), with `/api/*` proxied through to the
backend container. Point your browser at `http://localhost:8080`.

For local development without connectivity to AuraDB, an optional local
Neo4j Community container is available behind a Compose profile:

```bash
docker compose --profile local-neo4j up --build
# then set NEO4J_URI=bolt://neo4j:7687 in backend/.env
```

This local container is for dev/testing convenience only — production
deployment still targets AuraDB Free (or a paid tier once you outgrow it),
per the build spec.

## Notes on the offline sync model

- Every record's primary ID (case_id, parcel_id, etc.) is a client-generated
  UUID, created the moment a clerk starts filling out a form — online or
  offline. This lets two related records created in the same offline
  session (e.g. a new Case and its new filer Person) sync together
  consistently, since neither ID depends on a server round-trip.
- Writes made offline are queued in IndexedDB (`frontend/src/db/offlineDb.ts`)
  and flushed to `/api/sync/batch` on reconnect
  (`frontend/src/db/syncEngine.ts`).
- Conflicts (a record edited both offline and on the server since the last
  sync) are resolved last-write-wins, but every conflict is also recorded
  as a `SyncConflict` node and surfaced in **Admin → Sync Conflicts** for
  manual review — never resolved silently.
- Photos are resized and JPEG-compressed client-side
  (`frontend/src/utils/compressPhoto.ts`) before being queued, to stay
  within practical IndexedDB limits on low-end Android devices and keep
  sync payloads small on 2G/3G.

## Phase 2: WhatsApp/SMS intake

`backend/src/routes/intake.ts` exposes `POST /api/intake/case`, which
creates a `Case` node with `status: intake_pending` from a structured
payload (case type, quarter, reporter name/phone, respondent name,
description, photo reference). It's not wired to a real WhatsApp Business
API or Twilio webhook yet — do that by pointing the provider's webhook at
this endpoint, and fill in real signature/secret verification (a stub
shared-secret header check is already in place) before going live.
