import { Request, Response, NextFunction } from "express";
import jwt from "jsonwebtoken";

export type Role = "Commissioner" | "Clerk" | "Official" | "SuperAdmin";

export interface AuthedUser {
  email: string;
  name: string;
  picture?: string;
  role: Role;
}

declare global {
  // eslint-disable-next-line @typescript-eslint/no-namespace
  namespace Express {
    interface Request {
      user?: AuthedUser;
    }
  }
}

const { JWT_SECRET, SESSION_COOKIE_NAME = "jc_session" } = process.env;

export function requireAuth(req: Request, res: Response, next: NextFunction) {
  const token = req.cookies?.[SESSION_COOKIE_NAME];
  if (!token) {
    return res.status(401).json({ error: "Not authenticated" });
  }
  try {
    const payload = jwt.verify(token, JWT_SECRET as string) as AuthedUser;
    req.user = payload;
    next();
  } catch {
    return res.status(401).json({ error: "Session expired or invalid — please sign in again" });
  }
}
