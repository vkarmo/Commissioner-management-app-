import { Request, Response, NextFunction } from "express";
import { Role } from "./auth";

/** Restrict a route to one or more roles. Must run after requireAuth. */
export function requireRole(...allowed: Role[]) {
  return (req: Request, res: Response, next: NextFunction) => {
    if (!req.user) {
      return res.status(401).json({ error: "Not authenticated" });
    }
    if (!allowed.includes(req.user.role)) {
      return res.status(403).json({
        error: `This action requires one of these roles: ${allowed.join(", ")}`,
      });
    }
    next();
  };
}
