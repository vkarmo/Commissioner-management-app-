import { Router } from "express";
import { runQuery } from "../config/neo4j";
import { requireAuth } from "../middleware/auth";

const router = Router();
router.use(requireAuth);

// "At a glance" dashboard for the Commissioner: open case count, pending
// land disputes, recent revenue summary, public works needing attention.
router.get("/summary", async (req, res) => {
  const [openCases] = await runQuery(
    `MATCH (c:Case) WHERE c.status IN ['open', 'mediation', 'intake_pending']
     RETURN count(c) AS count`
  );
  const [pendingDisputes] = await runQuery(
    `MATCH (d:Dispute) WHERE d.resolved IS NULL OR d.resolved = false
     RETURN count(d) AS count`
  );
  const [revenueThisMonth] = await runQuery(
    `MATCH (r:RevenueRecord) WHERE r.date STARTS WITH $month
     RETURN sum(toFloat(r.amount)) AS total, count(r) AS record_count`,
    { month: new Date().toISOString().slice(0, 7) }
  );
  const [worksNeedingAttention] = await runQuery(
    `MATCH (pw:PublicWorksItem) WHERE pw.condition IN ['poor', 'critical', 'non_functional']
     RETURN count(pw) AS count`
  );
  const recentCases = await runQuery(
    `MATCH (c:Case) RETURN c ORDER BY c.filed_date DESC LIMIT 5`
  );

  res.json({
    openCaseCount: Number(openCases?.count ?? 0),
    pendingLandDisputes: Number(pendingDisputes?.count ?? 0),
    revenueThisMonth: {
      total: Number(revenueThisMonth?.total ?? 0),
      recordCount: Number(revenueThisMonth?.record_count ?? 0),
    },
    publicWorksNeedingAttention: Number(worksNeedingAttention?.count ?? 0),
    recentCases: recentCases.map((r) => r.c.properties),
  });
});

// Clerk view: only cases they're the filer/audit creator on, plus a
// simpler task list rather than the office-wide dashboard.
router.get("/my-tasks", async (req, res) => {
  const rows = await runQuery(
    `MATCH (c:Case) WHERE c.created_by = $email AND c.status IN ['intake_pending', 'open']
     RETURN c ORDER BY c.filed_date DESC LIMIT 25`,
    { email: req.user!.email }
  );
  res.json({ myOpenCases: rows.map((r) => r.c.properties) });
});

export default router;
