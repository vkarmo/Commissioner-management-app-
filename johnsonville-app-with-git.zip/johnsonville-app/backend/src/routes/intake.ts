import { Router } from "express";
import { v4 as uuidv4 } from "uuid";
import { runQuery } from "../config/neo4j";
import { stampCreate, logAuditEvent } from "../utils/audit";

const router = Router();

/**
 * Phase 2 stub: designed so a future WhatsApp Business API or Twilio/SMS
 * webhook can POST here directly to create an intake_pending Case without
 * any schema changes. NOT wired to a real webhook provider yet — this
 * route is intentionally unauthenticated-by-cookie (a citizen-facing bot
 * has no Google session) but should be protected with a shared-secret
 * header or provider signature verification once a real provider is
 * chosen. That check is stubbed below; fill it in before going live.
 */
router.post("/case", async (req, res) => {
  const INTAKE_SHARED_SECRET = process.env.INTAKE_SHARED_SECRET;
  if (INTAKE_SHARED_SECRET) {
    const provided = req.header("x-intake-secret");
    if (provided !== INTAKE_SHARED_SECRET) {
      return res.status(401).json({ error: "Invalid intake credentials" });
    }
  }

  const {
    case_type,
    quarter_id,
    reporter_name,
    reporter_phone,
    respondent_name,
    description,
    photo_ref,
  } = req.body || {};

  if (!case_type || !reporter_phone || !description) {
    return res.status(400).json({
      error: "case_type, reporter_phone, and description are required",
    });
  }

  const caseId = uuidv4();
  const stamp = stampCreate("intake-bot@system");

  await runQuery(
    `MERGE (c:Case {case_id: $caseId})
     ON CREATE SET c += $stamp
     SET c.type = $type,
         c.filed_date = date(),
         c.status = 'intake_pending',
         c.summary = $description,
         c.intake_photo_ref = $photoRef,
         c.intake_channel = 'whatsapp_sms'`,
    { caseId, stamp, type: case_type, description, photoRef: photo_ref || null }
  );

  if (quarter_id) {
    await runQuery(
      `MATCH (c:Case {case_id: $caseId}), (q:Quarter {quarter_id: $quarterId})
       MERGE (c)-[:LOCATED_IN]->(q)`,
      { caseId, quarterId: quarter_id }
    );
  }

  const reporterId = uuidv4();
  await runQuery(
    `MERGE (p:Person {person_id: $reporterId})
     ON CREATE SET p += $stamp, p.name = $name, p.phone = $phone, p.role = 'citizen'
     WITH p
     MATCH (c:Case {case_id: $caseId})
     MERGE (p)-[:FILED]->(c)`,
    { reporterId, stamp, name: reporter_name || "Unknown (WhatsApp/SMS)", phone: reporter_phone, caseId }
  );

  if (respondent_name) {
    const respondentId = uuidv4();
    await runQuery(
      `MERGE (r:Person {person_id: $respondentId})
       ON CREATE SET r += $stamp, r.name = $name, r.role = 'citizen'
       WITH r
       MATCH (c:Case {case_id: $caseId})
       MERGE (r)-[n:NAMED_IN]->(c)
       SET n.role = 'respondent'`,
      { respondentId, stamp, name: respondent_name, caseId }
    );
  }

  await logAuditEvent({
    actorEmail: "intake-bot@system",
    action: "create",
    entityLabel: "Case",
    entityId: caseId,
    details: "created via WhatsApp/SMS intake webhook",
  });

  res.status(201).json({ case_id: caseId, status: "intake_pending" });
});

export default router;
