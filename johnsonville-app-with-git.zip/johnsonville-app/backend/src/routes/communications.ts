import { Router } from "express";
import { v4 as uuidv4 } from "uuid";
import { runQuery } from "../config/neo4j";
import { requireAuth } from "../middleware/auth";
import { stampCreate, logAuditEvent } from "../utils/audit";

const router = Router();
router.use(requireAuth);

router.get("/", async (req, res) => {
  const { search, linkedOffice } = req.query;
  const conditions: string[] = [];
  const params: Record<string, any> = {};
  if (search) {
    conditions.push("toLower(c.subject) CONTAINS toLower($search)");
    params.search = search;
  }
  if (linkedOffice) {
    conditions.push("toLower(c.linked_office) CONTAINS toLower($linkedOffice)");
    params.linkedOffice = linkedOffice;
  }
  const where = conditions.length ? `WHERE ${conditions.join(" AND ")}` : "";

  const rows = await runQuery(
    `MATCH (c:CommunicationLog)
     ${where}
     RETURN c
     ORDER BY c.date DESC
     LIMIT 300`,
    params
  );
  res.json({ logs: rows.map((r) => r.c.properties) });
});

router.post("/", async (req, res) => {
  const { comm_id, from, to, date, subject, linked_office, notes } = req.body || {};
  if (!subject) return res.status(400).json({ error: "subject is required" });
  const id = comm_id || uuidv4();
  const stamp = stampCreate(req.user!.email);

  await runQuery(
    `MERGE (c:CommunicationLog {comm_id: $id})
     ON CREATE SET c += $stamp
     SET c.from = $from, c.to = $to, c.date = $date, c.subject = $subject,
         c.linked_office = $linkedOffice, c.notes = $notes`,
    {
      id,
      stamp,
      from: from ?? null,
      to: to ?? null,
      date: date || new Date().toISOString().slice(0, 10),
      subject,
      linkedOffice: linked_office ?? null,
      notes: notes ?? null,
    }
  );

  await logAuditEvent({ actorEmail: req.user!.email, action: "create", entityLabel: "CommunicationLog", entityId: id });
  res.status(201).json({ comm_id: id });
});

export default router;
