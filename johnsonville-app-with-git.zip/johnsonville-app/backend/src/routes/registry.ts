import { Router } from "express";
import { v4 as uuidv4 } from "uuid";
import { runQuery } from "../config/neo4j";
import { requireAuth } from "../middleware/auth";
import { stampCreate, stampEdit, logAuditEvent } from "../utils/audit";

const router = Router();
router.use(requireAuth);

// --- Quarters / Towns (administrative subdivisions, configurable — not
// hardcoded to a Western address format) ---

router.get("/quarters", async (_req, res) => {
  const rows = await runQuery(
    `MATCH (q:Quarter)
     OPTIONAL MATCH (t:Town)<-[:PART_OF]-(q)
     OPTIONAL MATCH (chief:Person)-[:CHIEF_OF]->(q)
     RETURN q, t.name AS town_name, chief.name AS chief_name, chief.phone AS chief_phone
     ORDER BY q.name`
  );
  res.json({
    quarters: rows.map((r) => ({
      ...r.q.properties,
      town_name: r.town_name,
      chief_name: r.chief_name,
      chief_phone: r.chief_phone,
    })),
  });
});

router.post("/quarters", async (req, res) => {
  const { quarter_id, name, town_id, population } = req.body || {};
  if (!name) return res.status(400).json({ error: "name is required" });
  const id = quarter_id || uuidv4();
  const stamp = stampCreate(req.user!.email);

  await runQuery(
    `MERGE (q:Quarter {quarter_id: $id})
     ON CREATE SET q += $stamp
     SET q.name = $name, q.population = $population`,
    { id, stamp, name, population: population ?? null }
  );

  if (town_id) {
    await runQuery(
      `MATCH (q:Quarter {quarter_id: $id}), (t:Town {town_id: $townId})
       MERGE (q)-[:PART_OF]->(t)`,
      { id, townId: town_id }
    );
  }

  await logAuditEvent({ actorEmail: req.user!.email, action: "create", entityLabel: "Quarter", entityId: id });
  res.status(201).json({ quarter_id: id });
});

router.post("/towns", async (req, res) => {
  const { town_id, name } = req.body || {};
  if (!name) return res.status(400).json({ error: "name is required" });
  const id = town_id || uuidv4();
  const stamp = stampCreate(req.user!.email);
  await runQuery(
    `MERGE (t:Town {town_id: $id}) ON CREATE SET t += $stamp SET t.name = $name`,
    { id, stamp, name }
  );
  res.status(201).json({ town_id: id });
});

// Assign a Person as chief of a Quarter
router.post("/quarters/:id/chief", async (req, res) => {
  const { person_id } = req.body || {};
  if (!person_id) return res.status(400).json({ error: "person_id required" });
  await runQuery(
    `MATCH (q:Quarter {quarter_id: $qId})
     OPTIONAL MATCH (old:Person)-[oldRel:CHIEF_OF]->(q)
     DELETE oldRel
     WITH q
     MATCH (p:Person {person_id: $pId})
     MERGE (p)-[:CHIEF_OF]->(q)`,
    { qId: req.params.id, pId: person_id }
  );
  res.json({ ok: true });
});

// --- Household / person directory ---

router.get("/persons", async (req, res) => {
  const { quarter, search } = req.query;
  const conditions: string[] = [];
  const params: Record<string, any> = {};
  if (quarter) {
    conditions.push("p.quarter = $quarter");
    params.quarter = quarter;
  }
  if (search) {
    conditions.push("(toLower(p.name) CONTAINS toLower($search) OR p.phone CONTAINS $search)");
    params.search = search;
  }
  const where = conditions.length ? `WHERE ${conditions.join(" AND ")}` : "";

  const rows = await runQuery(
    `MATCH (p:Person)
     ${where}
     RETURN p
     ORDER BY p.name
     LIMIT 300`,
    params
  );
  res.json({ persons: rows.map((r) => r.p.properties) });
});

router.post("/persons", async (req, res) => {
  const { person_id, name, phone, quarter, role } = req.body || {};
  if (!name) return res.status(400).json({ error: "name is required" });
  const id = person_id || uuidv4();
  const stamp = stampCreate(req.user!.email);

  await runQuery(
    `MERGE (p:Person {person_id: $id})
     ON CREATE SET p += $stamp
     SET p.name = $name, p.phone = $phone, p.quarter = $quarter, p.role = $role`,
    { id, stamp, name, phone: phone ?? null, quarter: quarter ?? null, role: role || "citizen" }
  );

  await logAuditEvent({ actorEmail: req.user!.email, action: "create", entityLabel: "Person", entityId: id });
  res.status(201).json({ person_id: id });
});

router.patch("/persons/:id", async (req, res) => {
  const { name, phone, quarter, role } = req.body || {};
  const stamp = stampEdit(req.user!.email);
  await runQuery(
    `MATCH (p:Person {person_id: $id})
     SET p.name = coalesce($name, p.name),
         p.phone = coalesce($phone, p.phone),
         p.quarter = coalesce($quarter, p.quarter),
         p.role = coalesce($role, p.role),
         p += $stamp`,
    { id: req.params.id, name: name ?? null, phone: phone ?? null, quarter: quarter ?? null, role: role ?? null, stamp }
  );
  res.json({ ok: true });
});

// --- Officials (commissioner/clerk/chief roster) ---

router.get("/officials", async (_req, res) => {
  const rows = await runQuery(`MATCH (o:Official) RETURN o ORDER BY o.name`);
  res.json({ officials: rows.map((r) => r.o.properties) });
});

router.post("/officials", async (req, res) => {
  const { official_id, name, role, office } = req.body || {};
  if (!name) return res.status(400).json({ error: "name is required" });
  const id = official_id || uuidv4();
  const stamp = stampCreate(req.user!.email);
  await runQuery(
    `MERGE (o:Official {official_id: $id})
     ON CREATE SET o += $stamp
     SET o.name = $name, o.role = $role, o.office = $office`,
    { id, stamp, name, role: role ?? null, office: office ?? null }
  );
  await logAuditEvent({ actorEmail: req.user!.email, action: "create", entityLabel: "Official", entityId: id });
  res.status(201).json({ official_id: id });
});

export default router;
