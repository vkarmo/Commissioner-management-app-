import { Router } from "express";
import { v4 as uuidv4 } from "uuid";
import neo4j from "neo4j-driver";
import { runQuery } from "../config/neo4j";
import { requireAuth } from "../middleware/auth";
import { stampCreate, stampEdit, logAuditEvent } from "../utils/audit";

const router = Router();
router.use(requireAuth);

const CASE_TYPES = ["land", "family", "debt", "chieftaincy", "criminal-referral", "other"];
const CASE_STATUSES = ["intake_pending", "open", "mediation", "resolved", "referred"];

// List / filter cases
router.get("/", async (req, res) => {
  const { quarter, status, type, from, to, search } = req.query;

  const conditions: string[] = [];
  const params: Record<string, any> = {};

  if (quarter) {
    conditions.push("q.quarter_id = $quarter");
    params.quarter = quarter;
  }
  if (status) {
    conditions.push("c.status = $status");
    params.status = status;
  }
  if (type) {
    conditions.push("c.type = $type");
    params.type = type;
  }
  if (from) {
    conditions.push("c.filed_date >= $from");
    params.from = from;
  }
  if (to) {
    conditions.push("c.filed_date <= $to");
    params.to = to;
  }
  if (search) {
    conditions.push("toLower(c.summary) CONTAINS toLower($search)");
    params.search = search;
  }

  const where = conditions.length ? `WHERE ${conditions.join(" AND ")}` : "";

  const rows = await runQuery(
    `MATCH (c:Case)
     OPTIONAL MATCH (c)-[:LOCATED_IN]->(q:Quarter)
     OPTIONAL MATCH (filer:Person)-[:FILED]->(c)
     ${where}
     RETURN c, q.name AS quarter_name, filer.name AS filer_name
     ORDER BY c.filed_date DESC
     LIMIT 200`,
    params,
    neo4j.session.READ
  );

  res.json({
    cases: rows.map((r) => ({
      ...r.c.properties,
      quarter_name: r.quarter_name,
      filer_name: r.filer_name,
    })),
  });
});

// Case detail with related hearings, parties, dispute/parcel link
router.get("/:id", async (req, res) => {
  const rows = await runQuery(
    `MATCH (c:Case {case_id: $id})
     OPTIONAL MATCH (filer:Person)-[:FILED]->(c)
     OPTIONAL MATCH (named:Person)-[n:NAMED_IN]->(c)
     OPTIONAL MATCH (c)-[:HEARD_AT]->(h:Hearing)
     OPTIONAL MATCH (official:Official)-[:PRESIDED_OVER]->(h)
     OPTIONAL MATCH (c)-[:LOCATED_IN]->(q:Quarter)
     OPTIONAL MATCH (c)-[:REFERRED_TO]->(ref:Official)
     OPTIONAL MATCH (c)<-[:LINKED_TO_CASE]-(d:Dispute)-[:SUBJECT_OF_LINK]->(parcel:Parcel)
     RETURN c, q.name AS quarter_name,
            collect(DISTINCT {name: filer.name, phone: filer.phone}) AS filers,
            collect(DISTINCT {name: named.name, role: n.role}) AS named_parties,
            collect(DISTINCT {hearing: h, official: official.name}) AS hearings,
            ref.name AS referred_to,
            collect(DISTINCT parcel.parcel_id) AS disputed_parcels`,
    { id: req.params.id }
  );

  if (rows.length === 0) return res.status(404).json({ error: "Case not found" });
  const r = rows[0];
  res.json({
    case: r.c.properties,
    quarter_name: r.quarter_name,
    filers: r.filers,
    named_parties: r.named_parties,
    hearings: r.hearings,
    referred_to: r.referred_to,
    disputed_parcels: r.disputed_parcels,
  });
});

// Create case (used by both the in-app intake form and, later, the offline
// sync endpoint / WhatsApp-SMS webhook — case_id is always client-generated
// so it can be created consistently across all three paths)
router.post("/", async (req, res) => {
  const {
    case_id,
    type,
    filed_date,
    status,
    summary,
    quarter_id,
    filer_person_id,
    filer_name,
    filer_phone,
    named_parties, // [{ person_id, name, phone, role }]
  } = req.body || {};

  if (!type || !CASE_TYPES.includes(type)) {
    return res.status(400).json({ error: `type must be one of: ${CASE_TYPES.join(", ")}` });
  }

  const id = case_id || uuidv4();
  const stamp = stampCreate(req.user!.email);

  await runQuery(
    `MERGE (c:Case {case_id: $id})
     ON CREATE SET c += $stamp
     SET c.type = $type,
         c.filed_date = $filed_date,
         c.status = $status,
         c.summary = $summary`,
    {
      id,
      stamp,
      type,
      filed_date: filed_date || new Date().toISOString().slice(0, 10),
      status: status && CASE_STATUSES.includes(status) ? status : "intake_pending",
      summary: summary || "",
    }
  );

  if (quarter_id) {
    await runQuery(
      `MATCH (c:Case {case_id: $id}), (q:Quarter {quarter_id: $quarter_id})
       MERGE (c)-[:LOCATED_IN]->(q)`,
      { id, quarter_id }
    );
  }

  // Filer: reuse existing Person by ID if given (offline-created records
  // carry client-generated person_id too), else find-or-create by phone.
  if (filer_person_id || filer_name) {
    const pId = filer_person_id || uuidv4();
    await runQuery(
      `MERGE (p:Person {person_id: $pId})
       ON CREATE SET p += $stamp, p.name = $name, p.phone = $phone, p.role = 'citizen'
       WITH p
       MATCH (c:Case {case_id: $id})
       MERGE (p)-[:FILED]->(c)`,
      { pId, stamp, name: filer_name || "Unknown", phone: filer_phone || null, id }
    );
  }

  if (Array.isArray(named_parties)) {
    for (const party of named_parties) {
      const pId = party.person_id || uuidv4();
      await runQuery(
        `MERGE (p:Person {person_id: $pId})
         ON CREATE SET p += $stamp, p.name = $name, p.phone = $phone, p.role = 'citizen'
         WITH p
         MATCH (c:Case {case_id: $id})
         MERGE (p)-[n:NAMED_IN]->(c)
         SET n.role = $role`,
        { pId, stamp, name: party.name || "Unknown", phone: party.phone || null, id, role: party.role || "respondent" }
      );
    }
  }

  await logAuditEvent({ actorEmail: req.user!.email, action: "create", entityLabel: "Case", entityId: id });
  res.status(201).json({ case_id: id });
});

router.patch("/:id", async (req, res) => {
  const { status, summary, type } = req.body || {};
  const stamp = stampEdit(req.user!.email);

  await runQuery(
    `MATCH (c:Case {case_id: $id})
     SET c.status = coalesce($status, c.status),
         c.summary = coalesce($summary, c.summary),
         c.type = coalesce($type, c.type),
         c += $stamp`,
    { id: req.params.id, status: status ?? null, summary: summary ?? null, type: type ?? null, stamp }
  );

  await logAuditEvent({ actorEmail: req.user!.email, action: "update", entityLabel: "Case", entityId: req.params.id });
  res.json({ ok: true });
});

// Schedule a hearing on a case
router.post("/:id/hearings", async (req, res) => {
  const { hearing_id, date, location, official_id } = req.body || {};
  const id = hearing_id || uuidv4();
  const stamp = stampCreate(req.user!.email);

  await runQuery(
    `MATCH (c:Case {case_id: $caseId})
     MERGE (h:Hearing {hearing_id: $id})
     ON CREATE SET h += $stamp
     SET h.date = $date, h.location = $location
     MERGE (c)-[:HEARD_AT]->(h)`,
    { caseId: req.params.id, id, stamp, date, location: location || null }
  );

  if (official_id) {
    await runQuery(
      `MATCH (h:Hearing {hearing_id: $id}), (o:Official {official_id: $officialId})
       MERGE (o)-[:PRESIDED_OVER]->(h)`,
      { id, officialId: official_id }
    );
  }

  await logAuditEvent({ actorEmail: req.user!.email, action: "create", entityLabel: "Hearing", entityId: id });
  res.status(201).json({ hearing_id: id });
});

// Log a hearing outcome
router.patch("/hearings/:hearingId", async (req, res) => {
  const { outcome_notes } = req.body || {};
  await runQuery(
    `MATCH (h:Hearing {hearing_id: $id})
     SET h.outcome_notes = $notes`,
    { id: req.params.hearingId, notes: outcome_notes || "" }
  );
  res.json({ ok: true });
});

// Refer a case to an official / County level
router.post("/:id/refer", async (req, res) => {
  const { official_id } = req.body || {};
  if (!official_id) return res.status(400).json({ error: "official_id required" });

  await runQuery(
    `MATCH (c:Case {case_id: $caseId}), (o:Official {official_id: $officialId})
     MERGE (c)-[:REFERRED_TO]->(o)
     SET c.status = 'referred'`,
    { caseId: req.params.id, officialId: official_id }
  );

  await logAuditEvent({ actorEmail: req.user!.email, action: "update", entityLabel: "Case", entityId: req.params.id, details: "referred" });
  res.json({ ok: true });
});

export default router;
