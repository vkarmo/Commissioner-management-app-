import { Router } from "express";
import { v4 as uuidv4 } from "uuid";
import { runQuery } from "../config/neo4j";
import { requireAuth } from "../middleware/auth";
import { stampCreate, stampEdit, logAuditEvent } from "../utils/audit";

const router = Router();
router.use(requireAuth);

// Lookup parcels by ID or owner name/phone
router.get("/parcels", async (req, res) => {
  const { search, quarter } = req.query;
  const conditions: string[] = [];
  const params: Record<string, any> = {};

  if (search) {
    conditions.push(
      "(toLower(p.parcel_id) CONTAINS toLower($search) OR toLower(owner.name) CONTAINS toLower($search))"
    );
    params.search = search;
  }
  if (quarter) {
    conditions.push("q.quarter_id = $quarter");
    params.quarter = quarter;
  }
  const where = conditions.length ? `WHERE ${conditions.join(" AND ")}` : "";

  const rows = await runQuery(
    `MATCH (p:Parcel)
     OPTIONAL MATCH (p)-[:WITHIN]->(q:Quarter)
     OPTIONAL MATCH (d:Deed)-[:COVERS]->(p)
     OPTIONAL MATCH (owner:Person)-[:HOLDS]->(d)
     OPTIONAL MATCH (p)-[:SUBJECT_OF]->(dispute:Dispute)
     RETURN p, q.name AS quarter_name, collect(DISTINCT owner.name) AS owners,
            count(DISTINCT dispute) > 0 AS has_open_dispute
     ${where}
     ORDER BY p.parcel_id
     LIMIT 200`,
    params
  );

  res.json({
    parcels: rows.map((r) => ({
      ...r.p.properties,
      quarter_name: r.quarter_name,
      owners: r.owners,
      has_open_dispute: r.has_open_dispute,
    })),
  });
});

// Parcel detail: deed history, adjacent parcels, dispute status
router.get("/parcels/:id", async (req, res) => {
  const rows = await runQuery(
    `MATCH (p:Parcel {parcel_id: $id})
     OPTIONAL MATCH (p)-[:WITHIN]->(q:Quarter)
     OPTIONAL MATCH (d:Deed)-[:COVERS]->(p)
     OPTIONAL MATCH (owner:Person)-[:HOLDS]->(d)
     OPTIONAL MATCH (p)-[:ADJACENT_TO]->(adj:Parcel)
     OPTIONAL MATCH (p)-[:SUBJECT_OF]->(dispute:Dispute)
     RETURN p, q.name AS quarter_name,
            collect(DISTINCT {deed: d, owner: owner.name}) AS deeds,
            collect(DISTINCT {parcel_id: adj.parcel_id, land_use: adj.land_use, geometry: adj.geometry}) AS adjacent_parcels,
            collect(DISTINCT dispute) AS disputes`,
    { id: req.params.id }
  );

  if (rows.length === 0) return res.status(404).json({ error: "Parcel not found" });
  const r = rows[0];
  res.json({
    parcel: r.p.properties,
    quarter_name: r.quarter_name,
    deeds: r.deeds.filter((d: any) => d.deed),
    adjacent_parcels: r.adjacent_parcels.filter((a: any) => a.parcel_id),
    disputes: r.disputes.map((d: any) => d.properties),
  });
});

router.post("/parcels", async (req, res) => {
  const { parcel_id, geometry, acreage, land_use, quarter_id } = req.body || {};
  const id = parcel_id || uuidv4();
  const stamp = stampCreate(req.user!.email);

  await runQuery(
    `MERGE (p:Parcel {parcel_id: $id})
     ON CREATE SET p += $stamp
     SET p.geometry = $geometry, p.acreage = $acreage, p.land_use = $land_use`,
    { id, stamp, geometry: geometry ? JSON.stringify(geometry) : null, acreage: acreage ?? null, land_use: land_use ?? null }
  );

  if (quarter_id) {
    await runQuery(
      `MATCH (p:Parcel {parcel_id: $id}), (q:Quarter {quarter_id: $quarter_id})
       MERGE (p)-[:WITHIN]->(q)`,
      { id, quarter_id }
    );
  }

  await logAuditEvent({ actorEmail: req.user!.email, action: "create", entityLabel: "Parcel", entityId: id });
  res.status(201).json({ parcel_id: id });
});

// Record adjacency between two parcels (used for encroachment/boundary
// queries without needing full geometric intersection).
router.post("/parcels/:id/adjacent/:otherId", async (req, res) => {
  await runQuery(
    `MATCH (a:Parcel {parcel_id: $id}), (b:Parcel {parcel_id: $otherId})
     MERGE (a)-[:ADJACENT_TO]->(b)
     MERGE (b)-[:ADJACENT_TO]->(a)`,
    { id: req.params.id, otherId: req.params.otherId }
  );
  res.json({ ok: true });
});

// Deeds
router.post("/deeds", async (req, res) => {
  const { deed_id, deed_number, issue_date, type, parcel_id, owner_person_id, owner_name, owner_phone } =
    req.body || {};
  const id = deed_id || uuidv4();
  const stamp = stampCreate(req.user!.email);

  await runQuery(
    `MERGE (d:Deed {deed_id: $id})
     ON CREATE SET d += $stamp
     SET d.deed_number = $deed_number, d.issue_date = $issue_date, d.type = $type`,
    { id, stamp, deed_number: deed_number ?? null, issue_date: issue_date ?? null, type: type ?? null }
  );

  if (parcel_id) {
    await runQuery(
      `MATCH (d:Deed {deed_id: $id}), (p:Parcel {parcel_id: $parcelId})
       MERGE (d)-[:COVERS]->(p)`,
      { id, parcelId: parcel_id }
    );
  }

  if (owner_person_id || owner_name) {
    const pId = owner_person_id || uuidv4();
    await runQuery(
      `MERGE (owner:Person {person_id: $pId})
       ON CREATE SET owner += $stamp, owner.name = $name, owner.phone = $phone
       WITH owner
       MATCH (d:Deed {deed_id: $id})
       MERGE (owner)-[:HOLDS]->(d)`,
      { pId, stamp, name: owner_name || "Unknown", phone: owner_phone || null, id }
    );
  }

  await logAuditEvent({ actorEmail: req.user!.email, action: "create", entityLabel: "Deed", entityId: id });
  res.status(201).json({ deed_id: id });
});

// Flag a parcel as subject to a dispute (links to a Case)
router.post("/disputes", async (req, res) => {
  const { dispute_id, parcel_id, case_id, notes } = req.body || {};
  if (!parcel_id || !case_id) {
    return res.status(400).json({ error: "parcel_id and case_id are required" });
  }
  const id = dispute_id || uuidv4();
  const stamp = stampCreate(req.user!.email);

  await runQuery(
    `MERGE (disp:Dispute {dispute_id: $id})
     ON CREATE SET disp += $stamp
     SET disp.notes = $notes
     WITH disp
     MATCH (p:Parcel {parcel_id: $parcelId}), (c:Case {case_id: $caseId})
     MERGE (p)-[:SUBJECT_OF]->(disp)
     MERGE (disp)-[:LINKED_TO_CASE]->(c)
     MERGE (disp)-[:SUBJECT_OF_LINK]->(p)`,
    { id, stamp, notes: notes || "", parcelId: parcel_id, caseId: case_id }
  );

  await logAuditEvent({ actorEmail: req.user!.email, action: "create", entityLabel: "Dispute", entityId: id });
  res.status(201).json({ dispute_id: id });
});

export default router;
