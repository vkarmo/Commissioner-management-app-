import { Router } from "express";
import { OAuth2Client } from "google-auth-library";
import jwt from "jsonwebtoken";
import { runQuery } from "../config/neo4j";
import { logAuditEvent } from "../utils/audit";
import { requireAuth } from "../middleware/auth";

const router = Router();

const {
  GOOGLE_CLIENT_ID,
  GOOGLE_CLIENT_SECRET,
  GOOGLE_CALLBACK_URL,
  JWT_SECRET,
  JWT_EXPIRES_IN = "8h",
  SESSION_COOKIE_NAME = "jc_session",
  CLIENT_ORIGIN = "http://localhost:5173",
  NODE_ENV = "development",
} = process.env;

const oauthClient = new OAuth2Client(
  GOOGLE_CLIENT_ID,
  GOOGLE_CLIENT_SECRET,
  GOOGLE_CALLBACK_URL
);

// Step 1: kick off the Google consent screen.
router.get("/google", (req, res) => {
  const url = oauthClient.generateAuthUrl({
    access_type: "online",
    scope: ["openid", "email", "profile"],
    prompt: "select_account",
  });
  res.redirect(url);
});

// Step 2: Google redirects back here with a code.
router.get("/google/callback", async (req, res) => {
  const code = req.query.code as string | undefined;
  if (!code) {
    return res.redirect(`${CLIENT_ORIGIN}/login?error=missing_code`);
  }

  try {
    const { tokens } = await oauthClient.getToken(code);
    const ticket = await oauthClient.verifyIdToken({
      idToken: tokens.id_token as string,
      audience: GOOGLE_CLIENT_ID,
    });
    const payload = ticket.getPayload();
    if (!payload?.email) {
      return res.redirect(`${CLIENT_ORIGIN}/login?error=no_email`);
    }

    const email = payload.email.toLowerCase();

    // Whitelist check — this is the gate. No whitelist entry, no access,
    // regardless of a valid Google login.
    const rows = await runQuery<{ role: string; active: boolean }>(
      `MATCH (w:WhitelistedUser {email: $email}) RETURN w.role AS role, w.active AS active`,
      { email }
    );

    if (rows.length === 0 || rows[0].active === false) {
      return res.redirect(
        `${CLIENT_ORIGIN}/login?error=not_authorized&message=${encodeURIComponent(
          "This Google account is not authorized. Contact the Commissioner's office to be added."
        )}`
      );
    }

    const role = rows[0].role;

    // Store only email/name/photo, as specified — no password, auth is
    // fully delegated to Google.
    await runQuery(
      `MERGE (p:Person {person_id: $email})
       ON CREATE SET p.created_at = datetime()
       SET p.email = $email,
           p.name = $name,
           p.picture = $picture,
           p.last_login_at = datetime()`,
      { email, name: payload.name || email, picture: payload.picture || null }
    );

    const sessionToken = jwt.sign(
      { email, name: payload.name, picture: payload.picture, role },
      JWT_SECRET as string,
      { expiresIn: JWT_EXPIRES_IN }
    );

    res.cookie(SESSION_COOKIE_NAME, sessionToken, {
      httpOnly: true,
      secure: NODE_ENV === "production",
      sameSite: "lax",
      maxAge: 8 * 60 * 60 * 1000,
    });

    await logAuditEvent({
      actorEmail: email,
      action: "login",
      entityLabel: "Person",
      entityId: email,
    });

    res.redirect(`${CLIENT_ORIGIN}/`);
  } catch (err) {
    // eslint-disable-next-line no-console
    console.error("[auth] Google OAuth callback failed", err);
    res.redirect(`${CLIENT_ORIGIN}/login?error=oauth_failed`);
  }
});

router.post("/logout", (req, res) => {
  res.clearCookie(SESSION_COOKIE_NAME);
  res.json({ ok: true });
});

router.get("/me", requireAuth, (req, res) => {
  res.json({ user: req.user });
});

export default router;
