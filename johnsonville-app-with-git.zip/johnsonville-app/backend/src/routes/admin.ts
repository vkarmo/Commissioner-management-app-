import { Router } from "express";
import { runQuery } from "../config/neo4j";
import { requireAuth } from "../middleware/auth";
import { requireRole } from "../middleware/roles";
import { logAuditEvent } from "../utils/audit";

const router = Router();
router.use(requireAuth);

// ---- Whitelist management (Super Admin only) ----

router.get("/whitelist", requireRole("SuperAdmin"), async (req, res) => {
  const rows = await runQuery(
    `MATCH (w:WhitelistedUser)
     RETURN w.email AS email, w.role AS role, w.active AS active,
            w.added_by AS added_by, w.added_at AS added_at
     ORDER BY w.added_at DESC`
  );
  res.json({ whitelist: rows });
});

router.post("/whitelist", requireRole("SuperAdmin"), async (req, res) => {
  const { email, role } = req.body || {};
  const validRoles = ["Commissioner", "Clerk", "Official", "SuperAdmin"];
  if (!email || !validRoles.includes(role)) {
    return res.status(400).json({ error: "email and a valid role are required" });
  }
  const normalizedEmail = String(email).toLowerCase().trim();

  await runQuery(
    `MERGE (w:WhitelistedUser {email: $email})
     ON CREATE SET w.added_by = $addedBy, w.added_at = datetime()
     SET w.role = $role, w.active = true`,
    { email: normalizedEmail, role, addedBy: req.user!.email }
  );

  await logAuditEvent({
    actorEmail: req.user!.email,
    action: "create",
    entityLabel: "WhitelistedUser",
    entityId: normalizedEmail,
    details: `role=${role}`,
  });

  res.status(201).json({ ok: true });
});

router.patch("/whitelist/:email", requireRole("SuperAdmin"), async (req, res) => {
  const email = req.params.email.toLowerCase();
  const { role, active } = req.body || {};

  await runQuery(
    `MATCH (w:WhitelistedUser {email: $email})
     SET w.role = coalesce($role, w.role),
         w.active = coalesce($active, w.active)
     RETURN w`,
    { email, role: role ?? null, active: active ?? null }
  );

  await logAuditEvent({
    actorEmail: req.user!.email,
    action: "update",
    entityLabel: "WhitelistedUser",
    entityId: email,
    details: JSON.stringify({ role, active }),
  });

  res.json({ ok: true });
});

router.delete("/whitelist/:email", requireRole("SuperAdmin"), async (req, res) => {
  const email = req.params.email.toLowerCase();
  await runQuery(`MATCH (w:WhitelistedUser {email: $email}) DETACH DELETE w`, { email });
  await logAuditEvent({
    actorEmail: req.user!.email,
    action: "delete",
    entityLabel: "WhitelistedUser",
    entityId: email,
  });
  res.json({ ok: true });
});

// ---- Audit log viewer ----

router.get("/audit-log", requireRole("SuperAdmin", "Commissioner"), async (req, res) => {
  const limit = Math.min(parseInt((req.query.limit as string) || "100", 10), 500);
  const rows = await runQuery(
    `MATCH (a:AuditEvent)
     RETURN a.audit_id AS audit_id, a.actor_email AS actor_email, a.action AS action,
            a.entity_label AS entity_label, a.entity_id AS entity_id, a.details AS details,
            a.at AS at
     ORDER BY a.at DESC
     LIMIT $limit`,
    { limit }
  );
  res.json({ events: rows });
});

// ---- AuraDB Free usage indicator ----
// Free tier caps at ~200K nodes / 400K relationships. This gives staff a
// heads-up well before hitting the ceiling rather than a failed write.

const AURA_FREE_NODE_CAP = 200_000;
const AURA_FREE_REL_CAP = 400_000;

router.get("/db-usage", requireRole("SuperAdmin", "Commissioner"), async (req, res) => {
  const [nodeCountRow] = await runQuery(`MATCH (n) RETURN count(n) AS c`);
  const [relCountRow] = await runQuery(`MATCH ()-[r]->() RETURN count(r) AS c`);

  const nodeCount = Number(nodeCountRow?.c ?? 0);
  const relCount = Number(relCountRow?.c ?? 0);
  const nodePct = nodeCount / AURA_FREE_NODE_CAP;
  const relPct = relCount / AURA_FREE_REL_CAP;
  const warningThreshold = 0.8;

  res.json({
    nodeCount,
    relCount,
    nodeCap: AURA_FREE_NODE_CAP,
    relCap: AURA_FREE_REL_CAP,
    nodePct,
    relPct,
    warning:
      nodePct >= warningThreshold || relPct >= warningThreshold
        ? "Approaching AuraDB Free tier limits. Plan an upgrade to a paid Aura tier or self-hosted Neo4j soon."
        : null,
  });
});

// ---- Sync conflict review queue ----

router.get("/sync-conflicts", requireRole("SuperAdmin", "Commissioner", "Clerk"), async (req, res) => {
  const rows = await runQuery(
    `MATCH (c:SyncConflict {needs_review: true})
     RETURN c
     ORDER BY c.detected_at DESC`
  );
  res.json({ conflicts: rows.map((r) => r.c.properties) });
});

router.post("/sync-conflicts/:id/resolve", requireRole("SuperAdmin", "Commissioner", "Clerk"), async (req, res) => {
  const { resolution } = req.body || {}; // "kept_server" | "kept_local" | "manual"
  await runQuery(
    `MATCH (c:SyncConflict {conflict_id: $id})
     SET c.needs_review = false,
         c.resolved_by = $resolvedBy,
         c.resolved_at = datetime(),
         c.resolution = $resolution`,
    { id: req.params.id, resolvedBy: req.user!.email, resolution: resolution || "manual" }
  );
  res.json({ ok: true });
});

export default router;
