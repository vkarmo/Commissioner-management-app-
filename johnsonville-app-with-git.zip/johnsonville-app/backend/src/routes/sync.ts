import { Router } from "express";
import { v4 as uuidv4 } from "uuid";
import { runQuery } from "../config/neo4j";
import { requireAuth } from "../middleware/auth";
import { logAuditEvent } from "../utils/audit";

const router = Router();
router.use(requireAuth);

/**
 * Generic sync target config: which node label + primary key property each
 * offline-queued entity type maps to, and which properties clerks are
 * allowed to write from an offline form. Kept intentionally simple —
 * relationship wiring for a given entity type happens in its normal
 * dedicated route (see cases.ts, land.ts, etc.) and can also be queued as
 * its own sync item referencing entities by their client-generated UUIDs.
 */
const SYNC_TARGETS: Record<string, { label: string; idProp: string; editable: string[] }> = {
  Case: { label: "Case", idProp: "case_id", editable: ["type", "filed_date", "status", "summary"] },
  Person: { label: "Person", idProp: "person_id", editable: ["name", "phone", "quarter", "role"] },
  Parcel: { label: "Parcel", idProp: "parcel_id", editable: ["geometry", "acreage", "land_use"] },
  RevenueRecord: { label: "RevenueRecord", idProp: "revenue_id", editable: ["type", "amount", "date", "collector"] },
  PublicWorksItem: {
    label: "PublicWorksItem",
    idProp: "public_works_id",
    editable: ["type", "condition", "gps_lat", "gps_lng", "photo_ref", "notes"],
  },
  CommunicationLog: {
    label: "CommunicationLog",
    idProp: "comm_id",
    editable: ["from", "to", "date", "subject", "linked_office", "notes"],
  },
  Meeting: { label: "Meeting", idProp: "meeting_id", editable: ["date", "location", "attendees", "summary"] },
};

interface QueuedItem {
  entity_type: keyof typeof SYNC_TARGETS;
  entity_id: string;
  op: "create" | "update";
  payload: Record<string, any>;
  // last_edited_at the client had cached when it started the offline edit —
  // used to detect whether the server record changed since, i.e. a conflict.
  base_last_edited_at?: string | null;
  client_updated_at: string;
}

router.post("/batch", async (req, res) => {
  const items: QueuedItem[] = req.body?.items || [];
  const results: { entity_id: string; status: "applied" | "conflict" | "error"; error?: string }[] = [];

  for (const item of items) {
    const target = SYNC_TARGETS[item.entity_type];
    if (!target) {
      results.push({ entity_id: item.entity_id, status: "error", error: `Unknown entity_type ${item.entity_type}` });
      continue;
    }

    try {
      const existingRows = await runQuery(
        `MATCH (n:${target.label} {${target.idProp}: $id}) RETURN n.last_edited_at AS last_edited_at`,
        { id: item.entity_id }
      );
      const serverLastEdited = existingRows[0]?.last_edited_at ?? null;

      const isConflict =
        item.op === "update" &&
        existingRows.length > 0 &&
        item.base_last_edited_at &&
        serverLastEdited &&
        String(serverLastEdited) !== String(item.base_last_edited_at);

      if (isConflict) {
        // Last-write-wins is applied (server keeps the most recent write by
        // wall clock), but we never resolve silently: a SyncConflict node
        // is created and surfaced in the admin/clerk review queue.
        const conflictId = uuidv4();
        await runQuery(
          `CREATE (c:SyncConflict {
            conflict_id: $conflictId,
            entity_type: $entityType,
            entity_id: $entityId,
            server_last_edited_at: $serverLastEdited,
            client_payload: $clientPayload,
            client_updated_at: $clientUpdatedAt,
            detected_at: datetime(),
            needs_review: true,
            reported_by: $reportedBy
          })`,
          {
            conflictId,
            entityType: item.entity_type,
            entityId: item.entity_id,
            serverLastEdited,
            clientPayload: JSON.stringify(item.payload),
            clientUpdatedAt: item.client_updated_at,
            reportedBy: req.user!.email,
          }
        );
      }

      // Apply the write regardless (last-write-wins), using only whitelisted
      // editable properties plus the audit stamp.
      const setClauses = target.editable
        .filter((p) => item.payload[p] !== undefined)
        .map((p) => `n.${p} = $payload.${p}`)
        .join(", ");

      await runQuery(
        `MERGE (n:${target.label} {${target.idProp}: $id})
         ON CREATE SET n.created_by = $actor, n.created_at = datetime()
         SET n.last_edited_by = $actor, n.last_edited_at = $clientUpdatedAt
         ${setClauses ? `, ${setClauses}` : ""}`,
        {
          id: item.entity_id,
          actor: req.user!.email,
          clientUpdatedAt: item.client_updated_at,
          payload: item.payload,
        }
      );

      await logAuditEvent({
        actorEmail: req.user!.email,
        action: "sync",
        entityLabel: target.label,
        entityId: item.entity_id,
        details: isConflict ? "applied with conflict flagged" : "applied",
      });

      results.push({ entity_id: item.entity_id, status: isConflict ? "conflict" : "applied" });
    } catch (err: any) {
      results.push({ entity_id: item.entity_id, status: "error", error: err.message });
    }
  }

  res.json({ results });
});

export default router;
