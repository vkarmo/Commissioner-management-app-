import { Router } from "express";
import { v4 as uuidv4 } from "uuid";
import { runQuery } from "../config/neo4j";
import { requireAuth } from "../middleware/auth";
import { stampCreate, logAuditEvent } from "../utils/audit";

const router = Router();
router.use(requireAuth);

router.get("/", async (req, res) => {
  const { quarter, month, collector } = req.query; // month: "2026-08"
  const conditions: string[] = [];
  const params: Record<string, any> = {};
  if (quarter) {
    conditions.push("q.quarter_id = $quarter");
    params.quarter = quarter;
  }
  if (month) {
    conditions.push("r.date STARTS WITH $month");
    params.month = month;
  }
  if (collector) {
    conditions.push("toLower(r.collector) CONTAINS toLower($collector)");
    params.collector = collector;
  }
  const where = conditions.length ? `WHERE ${conditions.join(" AND ")}` : "";

  const rows = await runQuery(
    `MATCH (r:RevenueRecord)
     OPTIONAL MATCH (r)-[:LOCATED_IN]->(q:Quarter)
     ${where}
     RETURN r, q.name AS quarter_name
     ORDER BY r.date DESC
     LIMIT 300`,
    params
  );
  res.json({ records: rows.map((r) => ({ ...r.r.properties, quarter_name: r.quarter_name })) });
});

// Monthly summary per quarter/collector
router.get("/summary", async (req, res) => {
  const { month } = req.query;
  const rows = await runQuery(
    `MATCH (r:RevenueRecord)
     OPTIONAL MATCH (r)-[:LOCATED_IN]->(q:Quarter)
     WHERE $month IS NULL OR r.date STARTS WITH $month
     RETURN q.name AS quarter_name, r.collector AS collector,
            sum(toFloat(r.amount)) AS total, count(r) AS record_count
     ORDER BY total DESC`,
    { month: month || null }
  );
  res.json({ summary: rows });
});

router.post("/", async (req, res) => {
  const { revenue_id, type, amount, date, collector, quarter_id, permit_id } = req.body || {};
  if (amount === undefined) return res.status(400).json({ error: "amount is required" });
  const id = revenue_id || uuidv4();
  const stamp = stampCreate(req.user!.email);

  await runQuery(
    `MERGE (r:RevenueRecord {revenue_id: $id})
     ON CREATE SET r += $stamp
     SET r.type = $type, r.amount = $amount, r.date = $date, r.collector = $collector`,
    {
      id,
      stamp,
      type: type || "market_due",
      amount,
      date: date || new Date().toISOString().slice(0, 10),
      collector: collector || req.user!.name,
    }
  );

  if (quarter_id) {
    await runQuery(
      `MATCH (r:RevenueRecord {revenue_id: $id}), (q:Quarter {quarter_id: $quarterId})
       MERGE (r)-[:LOCATED_IN]->(q)`,
      { id, quarterId: quarter_id }
    );
  }
  if (permit_id) {
    await runQuery(
      `MATCH (r:RevenueRecord {revenue_id: $id}), (p:MarketPermit {permit_id: $permitId})
       MERGE (r)-[:FOR_PERMIT]->(p)`,
      { id, permitId: permit_id }
    );
  }

  await logAuditEvent({ actorEmail: req.user!.email, action: "create", entityLabel: "RevenueRecord", entityId: id });
  res.status(201).json({ revenue_id: id });
});

router.post("/permits", async (req, res) => {
  const { permit_id, holder_name, permit_type, issued_date, quarter_id } = req.body || {};
  const id = permit_id || uuidv4();
  const stamp = stampCreate(req.user!.email);
  await runQuery(
    `MERGE (p:MarketPermit {permit_id: $id})
     ON CREATE SET p += $stamp
     SET p.holder_name = $holderName, p.permit_type = $permitType, p.issued_date = $issuedDate`,
    { id, stamp, holderName: holder_name ?? null, permitType: permit_type ?? null, issuedDate: issued_date ?? null }
  );
  if (quarter_id) {
    await runQuery(
      `MATCH (p:MarketPermit {permit_id: $id}), (q:Quarter {quarter_id: $quarterId})
       MERGE (p)-[:LOCATED_IN]->(q)`,
      { id, quarterId: quarter_id }
    );
  }
  await logAuditEvent({ actorEmail: req.user!.email, action: "create", entityLabel: "MarketPermit", entityId: id });
  res.status(201).json({ permit_id: id });
});

export default router;
