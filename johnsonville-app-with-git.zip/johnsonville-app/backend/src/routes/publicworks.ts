import { Router } from "express";
import { v4 as uuidv4 } from "uuid";
import { runQuery } from "../config/neo4j";
import { requireAuth } from "../middleware/auth";
import { stampCreate, stampEdit, logAuditEvent } from "../utils/audit";

const router = Router();
router.use(requireAuth);

const NEEDS_ATTENTION = ["poor", "critical", "non_functional"];

router.get("/", async (req, res) => {
  const { quarter, needsAttention, type } = req.query;
  const conditions: string[] = [];
  const params: Record<string, any> = {};
  if (quarter) {
    conditions.push("q.quarter_id = $quarter");
    params.quarter = quarter;
  }
  if (type) {
    conditions.push("pw.type = $type");
    params.type = type;
  }
  if (needsAttention === "true") {
    conditions.push("pw.condition IN $needsAttention");
    params.needsAttention = NEEDS_ATTENTION;
  }
  const where = conditions.length ? `WHERE ${conditions.join(" AND ")}` : "";

  const rows = await runQuery(
    `MATCH (pw:PublicWorksItem)
     OPTIONAL MATCH (pw)-[:LOCATED_IN]->(q:Quarter)
     ${where}
     RETURN pw, q.name AS quarter_name
     ORDER BY pw.last_updated DESC
     LIMIT 300`,
    params
  );
  res.json({
    items: rows.map((r) => ({ ...r.pw.properties, quarter_name: r.quarter_name })),
  });
});

router.post("/", async (req, res) => {
  const { public_works_id, type, condition, gps_lat, gps_lng, photo_ref, quarter_id, notes } = req.body || {};
  if (!type) return res.status(400).json({ error: "type is required" });
  const id = public_works_id || uuidv4();
  const stamp = stampCreate(req.user!.email);

  await runQuery(
    `MERGE (pw:PublicWorksItem {public_works_id: $id})
     ON CREATE SET pw += $stamp
     SET pw.type = $type, pw.condition = $condition, pw.gps_lat = $gpsLat,
         pw.gps_lng = $gpsLng, pw.photo_ref = $photoRef, pw.notes = $notes,
         pw.last_updated = datetime()`,
    {
      id,
      stamp,
      type,
      condition: condition || "unknown",
      gpsLat: gps_lat ?? null,
      gpsLng: gps_lng ?? null,
      photoRef: photo_ref ?? null,
      notes: notes ?? null,
    }
  );

  if (quarter_id) {
    await runQuery(
      `MATCH (pw:PublicWorksItem {public_works_id: $id}), (q:Quarter {quarter_id: $quarterId})
       MERGE (pw)-[:LOCATED_IN]->(q)`,
      { id, quarterId: quarter_id }
    );
  }

  await logAuditEvent({ actorEmail: req.user!.email, action: "create", entityLabel: "PublicWorksItem", entityId: id });
  res.status(201).json({ public_works_id: id });
});

router.patch("/:id", async (req, res) => {
  const { condition, notes, photo_ref } = req.body || {};
  const stamp = stampEdit(req.user!.email);
  await runQuery(
    `MATCH (pw:PublicWorksItem {public_works_id: $id})
     SET pw.condition = coalesce($condition, pw.condition),
         pw.notes = coalesce($notes, pw.notes),
         pw.photo_ref = coalesce($photoRef, pw.photo_ref),
         pw.last_updated = datetime(),
         pw += $stamp`,
    { id: req.params.id, condition: condition ?? null, notes: notes ?? null, photoRef: photo_ref ?? null, stamp }
  );
  await logAuditEvent({ actorEmail: req.user!.email, action: "update", entityLabel: "PublicWorksItem", entityId: req.params.id });
  res.json({ ok: true });
});

export default router;
