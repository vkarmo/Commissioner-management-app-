import { Router } from "express";
import { v4 as uuidv4 } from "uuid";
import { runQuery } from "../config/neo4j";
import { requireAuth } from "../middleware/auth";
import { stampCreate, logAuditEvent } from "../utils/audit";

const router = Router();
router.use(requireAuth);

router.get("/", async (req, res) => {
  const { quarter } = req.query;
  const conditions: string[] = [];
  const params: Record<string, any> = {};
  if (quarter) {
    conditions.push("q.quarter_id = $quarter");
    params.quarter = quarter;
  }
  const where = conditions.length ? `WHERE ${conditions.join(" AND ")}` : "";

  const rows = await runQuery(
    `MATCH (m:Meeting)
     OPTIONAL MATCH (m)-[:LOCATED_IN]->(q:Quarter)
     ${where}
     RETURN m, q.name AS quarter_name
     ORDER BY m.date DESC
     LIMIT 200`,
    params
  );
  res.json({ meetings: rows.map((r) => ({ ...r.m.properties, quarter_name: r.quarter_name })) });
});

router.post("/", async (req, res) => {
  const { meeting_id, date, location, attendees, summary, quarter_id } = req.body || {};
  if (!date) return res.status(400).json({ error: "date is required" });
  const id = meeting_id || uuidv4();
  const stamp = stampCreate(req.user!.email);

  await runQuery(
    `MERGE (m:Meeting {meeting_id: $id})
     ON CREATE SET m += $stamp
     SET m.date = $date, m.location = $location,
         m.attendees = $attendees, m.summary = $summary`,
    {
      id,
      stamp,
      date,
      location: location ?? null,
      attendees: Array.isArray(attendees) ? attendees : attendees ? [attendees] : [],
      summary: summary ?? null,
    }
  );

  if (quarter_id) {
    await runQuery(
      `MATCH (m:Meeting {meeting_id: $id}), (q:Quarter {quarter_id: $quarterId})
       MERGE (m)-[:LOCATED_IN]->(q)`,
      { id, quarterId: quarter_id }
    );
  }

  await logAuditEvent({ actorEmail: req.user!.email, action: "create", entityLabel: "Meeting", entityId: id });
  res.status(201).json({ meeting_id: id });
});

export default router;
