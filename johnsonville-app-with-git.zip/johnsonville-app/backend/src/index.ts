import dotenv from "dotenv";
dotenv.config();

import { createApp } from "./app";
import { ensureSchema } from "./models/schema";

const PORT = process.env.PORT || 4000;
const app = createApp();

async function start() {
  try {
    await ensureSchema();
  } catch (err) {
    // eslint-disable-next-line no-console
    console.error(
      "[startup] Could not ensure schema on boot (AuraDB Free may be waking from pause). Retrying in the background.",
      err
    );
  }
  app.listen(PORT, () => {
    // eslint-disable-next-line no-console
    console.log(`Johnsonville Commissioner's Office API listening on :${PORT}`);
  });
}

start();
