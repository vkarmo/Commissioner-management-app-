import express from "express";
import cors from "cors";
import helmet from "helmet";
import cookieParser from "cookie-parser";
import rateLimit from "express-rate-limit";

import { pingDatabase } from "./config/neo4j";

import authRoutes from "./routes/auth";
import caseRoutes from "./routes/cases";
import landRoutes from "./routes/land";
import registryRoutes from "./routes/registry";
import revenueRoutes from "./routes/revenue";
import publicWorksRoutes from "./routes/publicworks";
import communicationsRoutes from "./routes/communications";
import meetingsRoutes from "./routes/meetings";
import adminRoutes from "./routes/admin";
import syncRoutes from "./routes/sync";
import intakeRoutes from "./routes/intake";
import dashboardRoutes from "./routes/dashboard";

/**
 * Builds the Express app without starting it. Kept separate from
 * src/index.ts so tests (supertest) can import and exercise the app
 * without binding a port or running the schema-ensure step on boot.
 */
export function createApp() {
  const app = express();
  const CLIENT_ORIGIN = process.env.CLIENT_ORIGIN || "http://localhost:5173";

  app.use(helmet());
  app.use(cors({ origin: CLIENT_ORIGIN, credentials: true }));
  app.use(cookieParser());
  app.use(express.json({ limit: "5mb" }));

  app.use(
    rateLimit({
      windowMs: 15 * 60 * 1000,
      max: 300,
      standardHeaders: true,
      legacyHeaders: false,
    })
  );

  app.get("/api/health", async (_req, res) => {
    try {
      const result = await pingDatabase();
      res.json({ status: "ok", db: result });
    } catch (err: any) {
      res.status(503).json({ status: "db_unavailable", error: err.message });
    }
  });

  app.use("/api/auth", authRoutes);
  app.use("/api/cases", caseRoutes);
  app.use("/api/land", landRoutes);
  app.use("/api/registry", registryRoutes);
  app.use("/api/revenue", revenueRoutes);
  app.use("/api/public-works", publicWorksRoutes);
  app.use("/api/communications", communicationsRoutes);
  app.use("/api/meetings", meetingsRoutes);
  app.use("/api/admin", adminRoutes);
  app.use("/api/sync", syncRoutes);
  app.use("/api/intake", intakeRoutes);
  app.use("/api/dashboard", dashboardRoutes);

  app.use((req, res) => {
    res.status(404).json({ error: "Not found" });
  });

  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  app.use((err: any, req: express.Request, res: express.Response, _next: express.NextFunction) => {
    // eslint-disable-next-line no-console
    console.error(err);
    res.status(500).json({ error: "Internal server error" });
  });

  return app;
}
