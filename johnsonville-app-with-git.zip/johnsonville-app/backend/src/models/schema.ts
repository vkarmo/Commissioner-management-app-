import { runQuery } from "../config/neo4j";

/**
 * Uniqueness constraints for the core node types. Every primary ID is a
 * client-generatable UUID (see utils/uuid.ts / frontend db/offlineDb.ts) so
 * that records created while offline — including two related records
 * created in the same offline session, e.g. a new Person filing a new
 * Case — can be synced together as a consistent batch without waiting on
 * server-assigned IDs.
 *
 * NOTE: Aura Free supports standard uniqueness/existence constraints via
 * plain Cypher (no APOC needed for this part), so this runs fine there.
 */
const CONSTRAINTS: { label: string; property: string }[] = [
  { label: "Person", property: "person_id" },
  { label: "Official", property: "official_id" },
  { label: "Case", property: "case_id" },
  { label: "Hearing", property: "hearing_id" },
  { label: "Parcel", property: "parcel_id" },
  { label: "Deed", property: "deed_id" },
  { label: "Dispute", property: "dispute_id" },
  { label: "Quarter", property: "quarter_id" },
  { label: "Town", property: "town_id" },
  { label: "MarketPermit", property: "permit_id" },
  { label: "RevenueRecord", property: "revenue_id" },
  { label: "PublicWorksItem", property: "public_works_id" },
  { label: "CommunicationLog", property: "comm_id" },
  { label: "Meeting", property: "meeting_id" },
  { label: "WhitelistedUser", property: "email" },
  { label: "SyncConflict", property: "conflict_id" },
  { label: "AuditEvent", property: "audit_id" },
];

export async function ensureSchema(): Promise<void> {
  for (const { label, property } of CONSTRAINTS) {
    const name = `uniq_${label.toLowerCase()}_${property}`;
    await runQuery(
      `CREATE CONSTRAINT ${name} IF NOT EXISTS
       FOR (n:${label}) REQUIRE n.${property} IS UNIQUE`
    );
  }

  // A couple of lookup indexes worth having day one for common queries
  // (search by quarter, filter cases by status) — these are cheap on Aura
  // Free and avoid full label scans as data grows toward the tier's cap.
  await runQuery(
    `CREATE INDEX case_status_idx IF NOT EXISTS FOR (c:Case) ON (c.status)`
  );
  await runQuery(
    `CREATE INDEX case_type_idx IF NOT EXISTS FOR (c:Case) ON (c.type)`
  );
  await runQuery(
    `CREATE INDEX pw_condition_idx IF NOT EXISTS FOR (p:PublicWorksItem) ON (p.condition)`
  );

  // eslint-disable-next-line no-console
  console.log("[schema] constraints and indexes ensured");
}
