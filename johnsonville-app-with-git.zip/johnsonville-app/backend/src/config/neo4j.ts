import neo4j, { Driver, Session, SessionMode } from "neo4j-driver";
import dotenv from "dotenv";

dotenv.config();

const {
  NEO4J_URI,
  NEO4J_USERNAME,
  NEO4J_PASSWORD,
  NEO4J_WAKE_RETRY_ATTEMPTS = "6",
  NEO4J_WAKE_RETRY_BASE_MS = "1500",
} = process.env;

if (!NEO4J_URI || !NEO4J_USERNAME || !NEO4J_PASSWORD) {
  throw new Error(
    "Missing Neo4j connection env vars. Copy .env.example to .env and fill in your AuraDB Free credentials."
  );
}

// AuraDB Free instances auto-pause after a period of inactivity and take a
// few seconds to resume on the next connection attempt. We don't want a
// clerk's screen to show a raw connection error just because the DB was
// asleep, so every query goes through withRetry() below, which retries a
// handful of times with exponential backoff before giving up.
export const driver: Driver = neo4j.driver(
  NEO4J_URI,
  neo4j.auth.basic(NEO4J_USERNAME, NEO4J_PASSWORD),
  {
    maxConnectionLifetime: 3 * 60 * 60 * 1000,
    maxConnectionPoolSize: 20,
    connectionAcquisitionTimeout: 30_000,
  }
);

const RETRY_ATTEMPTS = parseInt(NEO4J_WAKE_RETRY_ATTEMPTS, 10);
const RETRY_BASE_MS = parseInt(NEO4J_WAKE_RETRY_BASE_MS, 10);

function isTransientAuraWakeError(err: any): boolean {
  const msg = String(err?.message || "").toLowerCase();
  const code = String(err?.code || "").toLowerCase();
  return (
    code.includes("serviceunavailable") ||
    code.includes("sessionexpired") ||
    msg.includes("connection") ||
    msg.includes("timeout") ||
    msg.includes("unavailable") ||
    msg.includes("routing")
  );
}

function sleep(ms: number) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

/**
 * Runs a Cypher query with retry/backoff, tolerating the delay caused by
 * AuraDB Free waking from auto-pause. Callers should use this instead of
 * opening sessions directly.
 */
export async function runQuery<T = any>(
  cypher: string,
  params: Record<string, any> = {},
  mode: SessionMode = neo4j.session.WRITE
): Promise<T[]> {
  let attempt = 0;
  let lastError: any;

  while (attempt < RETRY_ATTEMPTS) {
    const session: Session = driver.session({ defaultAccessMode: mode });
    try {
      const result = await session.run(cypher, params);
      return result.records.map((r) => r.toObject()) as T[];
    } catch (err) {
      lastError = err;
      if (!isTransientAuraWakeError(err) || attempt === RETRY_ATTEMPTS - 1) {
        throw err;
      }
      const backoff = RETRY_BASE_MS * Math.pow(2, attempt);
      // eslint-disable-next-line no-console
      console.warn(
        `[neo4j] transient error (likely AuraDB Free waking up), retrying in ${backoff}ms (attempt ${
          attempt + 1
        }/${RETRY_ATTEMPTS})`
      );
      await sleep(backoff);
      attempt += 1;
    } finally {
      await session.close();
    }
  }

  throw lastError;
}

/** Lightweight check used by the /api/health endpoint and the frontend
 * "waking up" indicator. */
export async function pingDatabase(): Promise<{ ok: boolean; wokeFromPause?: boolean }> {
  const start = Date.now();
  await runQuery("RETURN 1 AS ok", {}, neo4j.session.READ);
  const elapsed = Date.now() - start;
  return { ok: true, wokeFromPause: elapsed > 2000 };
}

export async function closeDriver() {
  await driver.close();
}
