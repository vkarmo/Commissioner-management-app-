import { v4 as uuidv4 } from "uuid";
import { runQuery } from "../config/neo4j";

/** Standard created_by/created_at/last_edited_by/last_edited_at properties
 * every node in the schema is required to carry, per the build spec —
 * this matters for legal defensibility of case and land records. */
export function stampCreate(actorEmail: string) {
  const now = new Date().toISOString();
  return {
    created_by: actorEmail,
    created_at: now,
    last_edited_by: actorEmail,
    last_edited_at: now,
  };
}

export function stampEdit(actorEmail: string) {
  return {
    last_edited_by: actorEmail,
    last_edited_at: new Date().toISOString(),
  };
}

/** Writes a lightweight AuditEvent node for the admin audit log viewer.
 * Kept separate from the node's own created_by/last_edited_by fields so we
 * retain a full history even across multiple edits. */
export async function logAuditEvent(params: {
  actorEmail: string;
  action: "create" | "update" | "delete" | "sync" | "login";
  entityLabel: string;
  entityId: string;
  details?: string;
}) {
  const { actorEmail, action, entityLabel, entityId, details } = params;
  await runQuery(
    `CREATE (a:AuditEvent {
      audit_id: $audit_id,
      actor_email: $actorEmail,
      action: $action,
      entity_label: $entityLabel,
      entity_id: $entityId,
      details: $details,
      at: datetime()
    })`,
    { audit_id: uuidv4(), actorEmail, action, entityLabel, entityId, details: details || null }
  );
}
