import fs from "fs";
import path from "path";
import dotenv from "dotenv";
import { runQuery, closeDriver } from "../config/neo4j";

dotenv.config();

const BACKUP_DIR = process.env.BACKUP_DIR || "./backups";

/**
 * AuraDB Free has no automated backup/point-in-time recovery, and this data
 * (case records, land records) is legally significant. This job dumps every
 * node and relationship to a timestamped JSON file. Run it on a schedule
 * (cron, systemd timer, or a scheduled task on whatever host runs the API)
 * and sync BACKUP_DIR offsite — e.g. `rclone sync ./backups remote:jc-backups`.
 *
 * This uses plain Cypher (no APOC export procedures) so it works fine on
 * AuraDB Free, which only exposes a limited APOC subset.
 */
async function runBackup() {
  if (!fs.existsSync(BACKUP_DIR)) {
    fs.mkdirSync(BACKUP_DIR, { recursive: true });
  }

  const nodes = await runQuery(
    `MATCH (n) RETURN labels(n) AS labels, properties(n) AS props, elementId(n) AS id`
  );
  const rels = await runQuery(
    `MATCH (a)-[r]->(b)
     RETURN elementId(a) AS from, elementId(b) AS to, type(r) AS type, properties(r) AS props`
  );

  const timestamp = new Date().toISOString().replace(/[:.]/g, "-");
  const outFile = path.join(BACKUP_DIR, `backup-${timestamp}.json`);

  fs.writeFileSync(
    outFile,
    JSON.stringify({ exportedAt: new Date().toISOString(), nodes, relationships: rels }, null, 2)
  );

  // eslint-disable-next-line no-console
  console.log(`[backup] wrote ${nodes.length} nodes and ${rels.length} relationships to ${outFile}`);

  // Keep the last 30 local backups only; offsite sync (rclone/cron) is
  // responsible for longer retention.
  const files = fs
    .readdirSync(BACKUP_DIR)
    .filter((f) => f.startsWith("backup-"))
    .sort();
  while (files.length > 30) {
    fs.unlinkSync(path.join(BACKUP_DIR, files.shift() as string));
  }
}

if (require.main === module) {
  runBackup()
    .then(() => closeDriver())
    .catch((err) => {
      // eslint-disable-next-line no-console
      console.error("[backup] failed", err);
      process.exit(1);
    });
}

export { runBackup };
