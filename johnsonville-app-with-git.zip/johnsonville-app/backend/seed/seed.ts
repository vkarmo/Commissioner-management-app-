import dotenv from "dotenv";
import { v4 as uuidv4 } from "uuid";
import { runQuery, closeDriver } from "../src/config/neo4j";
import { ensureSchema } from "../src/models/schema";

dotenv.config();

async function seed() {
  await ensureSchema();

  // --- Bootstrap super admins from env so someone can log in day one ---
  const bootstrapAdmins = (process.env.BOOTSTRAP_SUPER_ADMINS || "")
    .split(",")
    .map((e) => e.trim().toLowerCase())
    .filter(Boolean);

  for (const email of bootstrapAdmins) {
    await runQuery(
      `MERGE (w:WhitelistedUser {email: $email})
       ON CREATE SET w.added_by = 'seed_script', w.added_at = datetime()
       SET w.role = 'SuperAdmin', w.active = true`,
      { email }
    );
  }
  console.log(`Seeded ${bootstrapAdmins.length} bootstrap Super Admin(s).`);

  // --- Town + Quarters ---
  const townId = uuidv4();
  await runQuery(
    `MERGE (t:Town {town_id: $id}) SET t.name = 'Johnsonville', t.created_at = datetime()`,
    { id: townId }
  );

  const quarters = [
    { name: "Duport Road Quarter", population: 4200 },
    { name: "Peter's Town Quarter", population: 3100 },
    { name: "Boys Town Quarter", population: 2600 },
    { name: "Sinkor Extension Quarter", population: 5400 },
  ].map((q) => ({ ...q, quarter_id: uuidv4() }));

  for (const q of quarters) {
    await runQuery(
      `MATCH (t:Town {town_id: $townId})
       MERGE (q:Quarter {quarter_id: $id})
       SET q.name = $name, q.population = $population, q.created_at = datetime()
       MERGE (q)-[:PART_OF]->(t)`,
      { townId, id: q.quarter_id, name: q.name, population: q.population }
    );
  }
  console.log(`Seeded 1 town and ${quarters.length} quarters.`);

  // --- Officials ---
  const officials = [
    { name: "Hon. Josephine Wreh", role: "commissioner", office: "Office of the Commissioner" },
    { name: "Clerk Emmanuel Toe", role: "clerk", office: "Case Registry" },
    { name: "Chief Alfred Kollie", role: "chief", office: "Duport Road Quarter" },
  ].map((o) => ({ ...o, official_id: uuidv4() }));

  for (const o of officials) {
    await runQuery(
      `MERGE (o:Official {official_id: $id}) SET o.name = $name, o.role = $role, o.office = $office, o.created_at = datetime()`,
      o
    );
  }
  console.log(`Seeded ${officials.length} officials.`);

  // --- Sample people ---
  const people = [
    { name: "Marcus Doe", phone: "0770123456", quarter: quarters[0].quarter_id, role: "citizen" },
    { name: "Grace Kpangbai", phone: "0770234567", quarter: quarters[1].quarter_id, role: "citizen" },
    { name: "Samuel Nyema", phone: "0770345678", quarter: quarters[0].quarter_id, role: "citizen" },
  ].map((p) => ({ ...p, person_id: uuidv4() }));

  for (const p of people) {
    await runQuery(
      `MERGE (p:Person {person_id: $id}) SET p.name = $name, p.phone = $phone, p.quarter = $quarter, p.role = $role, p.created_at = datetime()`,
      p
    );
  }
  console.log(`Seeded ${people.length} people.`);

  // --- Sample parcels + a deed ---
  const parcelA = uuidv4();
  const parcelB = uuidv4();
  await runQuery(
    `MERGE (p:Parcel {parcel_id: $id})
     SET p.acreage = 0.75, p.land_use = 'residential', p.created_at = datetime()
     WITH p
     MATCH (q:Quarter {quarter_id: $quarterId})
     MERGE (p)-[:WITHIN]->(q)`,
    { id: parcelA, quarterId: quarters[0].quarter_id }
  );
  await runQuery(
    `MERGE (p:Parcel {parcel_id: $id})
     SET p.acreage = 1.2, p.land_use = 'residential', p.created_at = datetime()
     WITH p
     MATCH (q:Quarter {quarter_id: $quarterId})
     MERGE (p)-[:WITHIN]->(q)`,
    { id: parcelB, quarterId: quarters[0].quarter_id }
  );
  await runQuery(
    `MATCH (a:Parcel {parcel_id: $a}), (b:Parcel {parcel_id: $b})
     MERGE (a)-[:ADJACENT_TO]->(b) MERGE (b)-[:ADJACENT_TO]->(a)`,
    { a: parcelA, b: parcelB }
  );

  const deedId = uuidv4();
  await runQuery(
    `MERGE (d:Deed {deed_id: $id})
     SET d.deed_number = 'TC-2019-0451', d.issue_date = '2019-03-12', d.type = 'tribal certificate', d.created_at = datetime()
     WITH d
     MATCH (owner:Person {person_id: $ownerId}), (parcel:Parcel {parcel_id: $parcelId})
     MERGE (owner)-[:HOLDS]->(d)
     MERGE (d)-[:COVERS]->(parcel)`,
    { id: deedId, ownerId: people[0].person_id, parcelId: parcelA }
  );
  console.log("Seeded 2 parcels (adjacent) and 1 deed.");

  // --- Sample case (land dispute) ---
  const caseId = uuidv4();
  await runQuery(
    `MERGE (c:Case {case_id: $id})
     SET c.type = 'land', c.filed_date = date() - duration('P10D'), c.status = 'open',
         c.summary = 'Boundary encroachment dispute between adjacent parcel owners.', c.created_at = datetime()
     WITH c
     MATCH (filer:Person {person_id: $filerId}), (q:Quarter {quarter_id: $quarterId})
     MERGE (filer)-[:FILED]->(c)
     MERGE (c)-[:LOCATED_IN]->(q)`,
    { id: caseId, filerId: people[0].person_id, quarterId: quarters[0].quarter_id }
  );
  await runQuery(
    `MATCH (respondent:Person {person_id: $respondentId}), (c:Case {case_id: $caseId})
     MERGE (respondent)-[n:NAMED_IN]->(c)
     SET n.role = 'respondent'`,
    { respondentId: people[1].person_id, caseId }
  );

  const disputeId = uuidv4();
  await runQuery(
    `CREATE (d:Dispute {dispute_id: $id, notes: 'Fence moved onto neighboring parcel', created_at: datetime()})
     WITH d
     MATCH (p:Parcel {parcel_id: $parcelId}), (c:Case {case_id: $caseId})
     MERGE (p)-[:SUBJECT_OF]->(d)
     MERGE (d)-[:LINKED_TO_CASE]->(c)
     MERGE (d)-[:SUBJECT_OF_LINK]->(p)`,
    { id: disputeId, parcelId: parcelB, caseId }
  );
  console.log("Seeded 1 case with linked land dispute.");

  // --- Sample revenue + public works ---
  await runQuery(
    `MATCH (q:Quarter {quarter_id: $quarterId})
     CREATE (r:RevenueRecord {
       revenue_id: $id, type: 'market_due', amount: 150, date: date(),
       collector: 'Clerk Emmanuel Toe', created_at: datetime()
     })-[:LOCATED_IN]->(q)`,
    { id: uuidv4(), quarterId: quarters[1].quarter_id }
  );

  await runQuery(
    `MATCH (q:Quarter {quarter_id: $quarterId})
     CREATE (pw:PublicWorksItem {
       public_works_id: $id, type: 'water_point', condition: 'poor',
       gps_lat: 6.328, gps_lng: -10.797, last_updated: datetime(), created_at: datetime(),
       notes: 'Hand pump broken, needs part replacement'
     })-[:LOCATED_IN]->(q)`,
    { id: uuidv4(), quarterId: quarters[2].quarter_id }
  );
  console.log("Seeded 1 revenue record and 1 public works item needing attention.");

  console.log("\nSeed complete.");
}

seed()
  .then(() => closeDriver())
  .catch((err) => {
    console.error("Seed failed:", err);
    process.exit(1);
  });
