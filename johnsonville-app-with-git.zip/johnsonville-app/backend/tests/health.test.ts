import request from "supertest";

jest.mock("../src/config/neo4j", () => ({
  runQuery: jest.fn().mockResolvedValue([]),
  pingDatabase: jest.fn(),
}));

import { pingDatabase } from "../src/config/neo4j";
import { createApp } from "../src/app";

describe("GET /api/health", () => {
  const app = createApp();

  it("returns 200 with db info when AuraDB responds", async () => {
    (pingDatabase as jest.Mock).mockResolvedValueOnce({ ok: true, wokeFromPause: false });
    const res = await request(app).get("/api/health");
    expect(res.status).toBe(200);
    expect(res.body).toMatchObject({ status: "ok", db: { ok: true } });
  });

  it("surfaces a wokeFromPause flag when AuraDB Free was auto-paused", async () => {
    (pingDatabase as jest.Mock).mockResolvedValueOnce({ ok: true, wokeFromPause: true });
    const res = await request(app).get("/api/health");
    expect(res.body.db.wokeFromPause).toBe(true);
  });

  it("returns 503 rather than crashing when the database is unavailable", async () => {
    (pingDatabase as jest.Mock).mockRejectedValueOnce(new Error("connection refused"));
    const res = await request(app).get("/api/health");
    expect(res.status).toBe(503);
    expect(res.body.status).toBe("db_unavailable");
  });
});

describe("unmatched routes", () => {
  const app = createApp();

  it("returns a JSON 404 rather than an HTML error page", async () => {
    const res = await request(app).get("/api/does-not-exist");
    expect(res.status).toBe(404);
    expect(res.body).toEqual({ error: "Not found" });
  });
});

describe("protected routes without auth", () => {
  const app = createApp();

  it("rejects unauthenticated case list requests", async () => {
    const res = await request(app).get("/api/cases");
    expect(res.status).toBe(401);
  });

  it("rejects unauthenticated admin whitelist requests", async () => {
    const res = await request(app).get("/api/admin/whitelist");
    expect(res.status).toBe(401);
  });
});
