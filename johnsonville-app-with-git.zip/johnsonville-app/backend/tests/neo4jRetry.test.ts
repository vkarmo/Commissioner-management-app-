// This suite mocks neo4j-driver directly so we can simulate the transient
// connection errors AuraDB Free produces while waking from auto-pause,
// without needing a real database.

const mockSessionRun = jest.fn();
const mockSessionClose = jest.fn().mockResolvedValue(undefined);
const mockDriverSession = jest.fn(() => ({ run: mockSessionRun, close: mockSessionClose }));
const mockDriverClose = jest.fn().mockResolvedValue(undefined);

jest.mock("neo4j-driver", () => ({
  __esModule: true,
  default: {
    driver: jest.fn(() => ({ session: mockDriverSession, close: mockDriverClose })),
    auth: { basic: jest.fn() },
    session: { WRITE: "WRITE", READ: "READ" },
  },
}));

describe("runQuery retry/backoff for AuraDB Free auto-pause", () => {
  beforeEach(() => {
    jest.resetModules();
    mockSessionRun.mockReset();
    mockDriverSession.mockClear();
  });

  it("returns results immediately when the query succeeds on the first try", async () => {
    mockSessionRun.mockResolvedValueOnce({
      records: [{ toObject: () => ({ ok: 1 }) }],
    });

    const { runQuery } = require("../src/config/neo4j");
    const result = await runQuery("RETURN 1 AS ok");

    expect(result).toEqual([{ ok: 1 }]);
    expect(mockSessionRun).toHaveBeenCalledTimes(1);
  });

  it("retries with backoff on a transient ServiceUnavailable error (AuraDB waking up), then succeeds", async () => {
    const transientError: any = new Error("Could not perform discovery. Connection unavailable");
    transientError.code = "ServiceUnavailable";

    mockSessionRun
      .mockRejectedValueOnce(transientError)
      .mockResolvedValueOnce({ records: [{ toObject: () => ({ ok: 1 }) }] });

    const { runQuery } = require("../src/config/neo4j");
    const result = await runQuery("RETURN 1 AS ok");

    expect(result).toEqual([{ ok: 1 }]);
    expect(mockSessionRun).toHaveBeenCalledTimes(2);
  });

  it("gives up after NEO4J_WAKE_RETRY_ATTEMPTS and surfaces the last error", async () => {
    const transientError: any = new Error("connection timeout");
    transientError.code = "ServiceUnavailable";
    mockSessionRun.mockRejectedValue(transientError);

    const { runQuery } = require("../src/config/neo4j");
    // setupEnv.ts sets NEO4J_WAKE_RETRY_ATTEMPTS=3
    await expect(runQuery("RETURN 1 AS ok")).rejects.toThrow("connection timeout");
    expect(mockSessionRun).toHaveBeenCalledTimes(3);
  });

  it("does not retry non-transient errors (e.g. a Cypher syntax error)", async () => {
    const syntaxError: any = new Error("Invalid input 'X': expected 'MATCH'");
    syntaxError.code = "Neo.ClientError.Statement.SyntaxError";
    mockSessionRun.mockRejectedValueOnce(syntaxError);

    const { runQuery } = require("../src/config/neo4j");
    await expect(runQuery("BAD CYPHER")).rejects.toThrow("Invalid input");
    expect(mockSessionRun).toHaveBeenCalledTimes(1);
  });

  it("always closes the session, even on failure", async () => {
    mockSessionRun.mockResolvedValueOnce({ records: [] });
    const { runQuery } = require("../src/config/neo4j");
    await runQuery("RETURN 1");
    expect(mockSessionClose).toHaveBeenCalled();
  });
});
