jest.mock("../src/config/neo4j", () => ({
  runQuery: jest.fn().mockResolvedValue([]),
}));

import { runQuery } from "../src/config/neo4j";
import { ensureSchema } from "../src/models/schema";

describe("ensureSchema", () => {
  beforeEach(() => {
    (runQuery as jest.Mock).mockClear();
  });

  it("issues a uniqueness constraint for every core node type in the data model", async () => {
    await ensureSchema();

    const cypherCalls = (runQuery as jest.Mock).mock.calls.map((c) => c[0]);
    const constraintCalls = cypherCalls.filter((c: string) => c.includes("CREATE CONSTRAINT"));

    // Spot-check the backbone entities called out in the build spec.
    const expectedLabels = [
      "Case",
      "Parcel",
      "Deed",
      "Person",
      "Quarter",
      "WhitelistedUser",
      "SyncConflict",
      "AuditEvent",
    ];
    for (const label of expectedLabels) {
      expect(constraintCalls.some((c: string) => c.includes(`FOR (n:${label})`))).toBe(true);
    }
  });

  it("constraints are idempotent (IF NOT EXISTS) so re-running on boot is safe", async () => {
    await ensureSchema();
    const cypherCalls = (runQuery as jest.Mock).mock.calls.map((c) => c[0]);
    const constraintCalls = cypherCalls.filter((c: string) => c.includes("CREATE CONSTRAINT"));
    expect(constraintCalls.length).toBeGreaterThan(0);
    expect(constraintCalls.every((c: string) => c.includes("IF NOT EXISTS"))).toBe(true);
  });

  it("creates lookup indexes for common Case and PublicWorksItem filters", async () => {
    await ensureSchema();
    const cypherCalls = (runQuery as jest.Mock).mock.calls.map((c) => c[0]);
    expect(cypherCalls.some((c: string) => c.includes("case_status_idx"))).toBe(true);
    expect(cypherCalls.some((c: string) => c.includes("pw_condition_idx"))).toBe(true);
  });
});
