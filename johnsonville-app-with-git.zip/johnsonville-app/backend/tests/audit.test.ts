import { stampCreate, stampEdit } from "../src/utils/audit";

jest.mock("../src/config/neo4j", () => ({
  runQuery: jest.fn().mockResolvedValue([]),
}));

import { runQuery } from "../src/config/neo4j";
import { logAuditEvent } from "../src/utils/audit";

describe("audit stamps", () => {
  it("stampCreate sets created_by/created_at and matching last_edited fields", () => {
    const stamp = stampCreate("clerk@example.com");
    expect(stamp.created_by).toBe("clerk@example.com");
    expect(stamp.last_edited_by).toBe("clerk@example.com");
    expect(stamp.created_at).toBe(stamp.last_edited_at);
    expect(new Date(stamp.created_at).toString()).not.toBe("Invalid Date");
  });

  it("stampEdit only touches last_edited fields", () => {
    const stamp = stampEdit("commissioner@example.com");
    expect(Object.keys(stamp).sort()).toEqual(["last_edited_at", "last_edited_by"]);
    expect(stamp.last_edited_by).toBe("commissioner@example.com");
  });

  it("stampCreate/stampEdit produce ISO 8601 timestamps", () => {
    const iso8601 = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z$/;
    expect(stampCreate("a@b.com").created_at).toMatch(iso8601);
    expect(stampEdit("a@b.com").last_edited_at).toMatch(iso8601);
  });
});

describe("logAuditEvent", () => {
  beforeEach(() => {
    (runQuery as jest.Mock).mockClear();
  });

  it("writes an AuditEvent node with the given action and entity details", async () => {
    await logAuditEvent({
      actorEmail: "clerk@example.com",
      action: "create",
      entityLabel: "Case",
      entityId: "case-123",
      details: "test details",
    });

    expect(runQuery).toHaveBeenCalledTimes(1);
    const [cypher, params] = (runQuery as jest.Mock).mock.calls[0];
    expect(cypher).toContain("CREATE (a:AuditEvent");
    expect(params).toMatchObject({
      actorEmail: "clerk@example.com",
      action: "create",
      entityLabel: "Case",
      entityId: "case-123",
      details: "test details",
    });
    expect(typeof params.audit_id).toBe("string");
  });

  it("defaults details to null when not provided", async () => {
    await logAuditEvent({
      actorEmail: "clerk@example.com",
      action: "login",
      entityLabel: "Person",
      entityId: "clerk@example.com",
    });
    const [, params] = (runQuery as jest.Mock).mock.calls[0];
    expect(params.details).toBeNull();
  });
});
