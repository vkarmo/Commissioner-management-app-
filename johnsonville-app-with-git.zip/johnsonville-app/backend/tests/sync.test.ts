import request from "supertest";
import express from "express";

const mockRunQuery = jest.fn();

jest.mock("../src/config/neo4j", () => ({
  runQuery: (...args: any[]) => mockRunQuery(...args),
  pingDatabase: jest.fn(),
}));

// Bypass real Google-issued JWT auth so we can drive the route directly;
// the auth gate itself is covered separately in health.test.ts.
jest.mock("../src/middleware/auth", () => ({
  requireAuth: (req: any, _res: any, next: any) => {
    req.user = { email: "clerk@example.com", name: "Test Clerk", role: "Clerk" };
    next();
  },
}));

import syncRoutes from "../src/routes/sync";

function buildApp() {
  const app = express();
  app.use(express.json());
  app.use("/api/sync", syncRoutes);
  return app;
}

describe("POST /api/sync/batch", () => {
  beforeEach(() => {
    mockRunQuery.mockReset();
  });

  it("applies a create with no prior server record cleanly (no conflict)", async () => {
    // First call: existence/last_edited_at check -> no rows (brand new record)
    mockRunQuery.mockResolvedValueOnce([]);
    // Second call: the MERGE write itself
    mockRunQuery.mockResolvedValueOnce([]);

    const app = buildApp();
    const res = await request(app)
      .post("/api/sync/batch")
      .send({
        items: [
          {
            entity_type: "Case",
            entity_id: "case-abc",
            op: "create",
            payload: { type: "land", summary: "New case filed offline" },
            base_last_edited_at: null,
            client_updated_at: "2026-08-09T10:00:00.000Z",
          },
        ],
      });

    expect(res.status).toBe(200);
    expect(res.body.results[0]).toMatchObject({ entity_id: "case-abc", status: "applied" });
  });

  it("flags a conflict when the server record changed since the client's cached version", async () => {
    // Existing row on the server has a newer last_edited_at than what the
    // offline client had cached when it started editing.
    mockRunQuery.mockResolvedValueOnce([{ last_edited_at: "2026-08-09T09:00:00.000Z" }]);
    mockRunQuery.mockResolvedValueOnce([]); // CREATE SyncConflict
    mockRunQuery.mockResolvedValueOnce([]); // the MERGE write (still applied, last-write-wins)

    const app = buildApp();
    const res = await request(app)
      .post("/api/sync/batch")
      .send({
        items: [
          {
            entity_type: "Case",
            entity_id: "case-xyz",
            op: "update",
            payload: { status: "resolved" },
            base_last_edited_at: "2026-08-08T08:00:00.000Z", // stale, server moved on
            client_updated_at: "2026-08-09T10:00:00.000Z",
          },
        ],
      });

    expect(res.status).toBe(200);
    expect(res.body.results[0]).toMatchObject({ entity_id: "case-xyz", status: "conflict" });

    // A SyncConflict node must have been created and flagged for review,
    // never resolved silently.
    const conflictCreateCall = mockRunQuery.mock.calls.find((c) => c[0].includes("CREATE (c:SyncConflict"));
    expect(conflictCreateCall).toBeDefined();
    expect(conflictCreateCall![1]).toMatchObject({ entityId: "case-xyz", reportedBy: "clerk@example.com" });
  });

  it("does not flag a conflict when the client's base timestamp matches the server's", async () => {
    mockRunQuery.mockResolvedValueOnce([{ last_edited_at: "2026-08-09T09:00:00.000Z" }]);
    mockRunQuery.mockResolvedValueOnce([]); // the MERGE write

    const app = buildApp();
    const res = await request(app)
      .post("/api/sync/batch")
      .send({
        items: [
          {
            entity_type: "Case",
            entity_id: "case-consistent",
            op: "update",
            payload: { status: "open" },
            base_last_edited_at: "2026-08-09T09:00:00.000Z", // matches server
            client_updated_at: "2026-08-09T10:00:00.000Z",
          },
        ],
      });

    expect(res.body.results[0].status).toBe("applied");
    const conflictCreateCall = mockRunQuery.mock.calls.find((c) => c[0].includes("CREATE (c:SyncConflict"));
    expect(conflictCreateCall).toBeUndefined();
  });

  it("rejects unknown entity types without touching the database", async () => {
    const app = buildApp();
    const res = await request(app)
      .post("/api/sync/batch")
      .send({
        items: [
          {
            entity_type: "NotARealType",
            entity_id: "whatever",
            op: "create",
            payload: {},
            client_updated_at: "2026-08-09T10:00:00.000Z",
          },
        ],
      });

    expect(res.body.results[0].status).toBe("error");
    expect(mockRunQuery).not.toHaveBeenCalled();
  });

  it("processes multiple queued items in one batch and reports per-item status", async () => {
    mockRunQuery
      .mockResolvedValueOnce([]) // item 1: existence check
      .mockResolvedValueOnce([]) // item 1: write
      .mockResolvedValueOnce([]) // item 2: existence check
      .mockResolvedValueOnce([]); // item 2: write

    const app = buildApp();
    const res = await request(app)
      .post("/api/sync/batch")
      .send({
        items: [
          {
            entity_type: "PublicWorksItem",
            entity_id: "pw-1",
            op: "create",
            payload: { type: "water_point", condition: "poor" },
            client_updated_at: "2026-08-09T10:00:00.000Z",
          },
          {
            entity_type: "RevenueRecord",
            entity_id: "rev-1",
            op: "create",
            payload: { amount: 100 },
            client_updated_at: "2026-08-09T10:01:00.000Z",
          },
        ],
      });

    expect(res.body.results).toHaveLength(2);
    expect(res.body.results.map((r: any) => r.status)).toEqual(["applied", "applied"]);
  });
});
