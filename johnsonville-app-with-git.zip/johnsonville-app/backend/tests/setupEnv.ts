// Dummy env vars so modules that read process.env at import time (e.g.
// config/neo4j.ts, routes/auth.ts) don't throw during test collection.
process.env.NEO4J_URI = "neo4j+s://test.databases.neo4j.io";
process.env.NEO4J_USERNAME = "neo4j";
process.env.NEO4J_PASSWORD = "test-password";
process.env.NEO4J_WAKE_RETRY_ATTEMPTS = "3";
process.env.NEO4J_WAKE_RETRY_BASE_MS = "10"; // fast retries in tests
process.env.GOOGLE_CLIENT_ID = "test-client-id";
process.env.GOOGLE_CLIENT_SECRET = "test-client-secret";
process.env.GOOGLE_CALLBACK_URL = "http://localhost:4000/api/auth/google/callback";
process.env.JWT_SECRET = "test-jwt-secret";
process.env.JWT_EXPIRES_IN = "8h";
process.env.CLIENT_ORIGIN = "http://localhost:5173";
process.env.NODE_ENV = "test";
