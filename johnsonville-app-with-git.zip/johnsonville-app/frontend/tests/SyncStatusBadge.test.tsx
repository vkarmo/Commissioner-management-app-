import { describe, it, expect } from "vitest";
import { render, screen } from "@testing-library/react";
import SyncStatusBadge from "../src/components/SyncStatusBadge";

// subscribeSyncState is called on mount and pushes state synchronously, so
// we can drive it deterministically by importing the module state setters
// is not exposed — instead we assert on the real initial state and the
// component's ability to render each branch by mocking the module.
import * as syncEngine from "../src/db/syncEngine";
import { vi } from "vitest";

function mockState(partial: Partial<syncEngine.SyncState>) {
  vi.spyOn(syncEngine, "subscribeSyncState").mockImplementation((listener) => {
    listener({
      isOnline: true,
      pending: 0,
      syncing: false,
      lastSyncAt: null,
      lastError: null,
      conflictsThisSync: 0,
      ...partial,
    });
    return () => {};
  });
}

describe("SyncStatusBadge", () => {
  it("shows an offline indicator with pending count when offline", () => {
    mockState({ isOnline: false, pending: 3 });
    render(<SyncStatusBadge />);
    expect(screen.getByText(/Offline/)).toBeInTheDocument();
    expect(screen.getByText(/3 records pending sync/)).toBeInTheDocument();
  });

  it("shows a syncing indicator while a sync is in progress", () => {
    mockState({ isOnline: true, syncing: true });
    render(<SyncStatusBadge />);
    expect(screen.getByText(/Syncing/)).toBeInTheDocument();
  });

  it("shows pending count when online but not yet synced", () => {
    mockState({ isOnline: true, syncing: false, pending: 1 });
    render(<SyncStatusBadge />);
    expect(screen.getByText(/1 record pending sync/)).toBeInTheDocument();
  });

  it("shows an all-synced indicator when there is nothing pending", () => {
    mockState({ isOnline: true, syncing: false, pending: 0 });
    render(<SyncStatusBadge />);
    expect(screen.getByText(/All synced/)).toBeInTheDocument();
  });
});
