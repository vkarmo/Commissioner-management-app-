import { describe, it, expect, beforeEach } from "vitest";
import {
  offlineDb,
  generateId,
  queueWrite,
  pendingCount,
  cacheList,
  getCachedList,
} from "../src/db/offlineDb";

beforeEach(async () => {
  await offlineDb.writeQueue.clear();
  await offlineDb.cache.clear();
});

describe("generateId", () => {
  it("produces unique client-side UUIDs", () => {
    const ids = new Set(Array.from({ length: 50 }, () => generateId()));
    expect(ids.size).toBe(50);
  });

  it("produces RFC-4122-shaped v4 UUIDs", () => {
    const id = generateId();
    expect(id).toMatch(/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i);
  });
});

describe("queueWrite", () => {
  it("adds a pending entry to the write queue", async () => {
    const id = generateId();
    await queueWrite({
      entity_type: "Case",
      entity_id: id,
      op: "create",
      payload: { type: "land", summary: "Test case filed offline" },
    });

    const queued = await offlineDb.writeQueue.toArray();
    expect(queued).toHaveLength(1);
    expect(queued[0]).toMatchObject({
      entity_type: "Case",
      entity_id: id,
      op: "create",
      status: "pending",
    });
  });

  it("immediately updates the local cache so UI reflects the change before syncing", async () => {
    const id = generateId();
    await queueWrite({
      entity_type: "PublicWorksItem",
      entity_id: id,
      op: "create",
      payload: { type: "water_point", condition: "poor" },
    });

    const cached = await getCachedList("PublicWorksItem");
    expect(cached).toHaveLength(1);
    expect(cached[0]).toMatchObject({ public_works_id: id, condition: "poor" });
  });

  it("allows two related offline-created records (e.g. a Case and its filer Person) to queue independently with client-generated ids", async () => {
    const caseId = generateId();
    const personId = generateId();

    await queueWrite({
      entity_type: "Person",
      entity_id: personId,
      op: "create",
      payload: { name: "Marcus Doe", phone: "0770123456" },
    });
    await queueWrite({
      entity_type: "Case",
      entity_id: caseId,
      op: "create",
      payload: { type: "land", filer_person_id: personId },
    });

    const queued = await offlineDb.writeQueue.toArray();
    expect(queued).toHaveLength(2);
    // Both ids are independently valid and don't depend on a server round trip
    expect(queued.find((q) => q.entity_type === "Person")?.entity_id).toBe(personId);
    expect(queued.find((q) => q.entity_type === "Case")?.payload.filer_person_id).toBe(personId);
  });

  it("records base_last_edited_at as null when not supplied (new record)", async () => {
    const id = generateId();
    await queueWrite({ entity_type: "Meeting", entity_id: id, op: "create", payload: { date: "2026-08-09" } });
    const [item] = await offlineDb.writeQueue.toArray();
    expect(item.base_last_edited_at).toBeNull();
  });
});

describe("pendingCount", () => {
  it("counts only pending items", async () => {
    await queueWrite({ entity_type: "Meeting", entity_id: generateId(), op: "create", payload: {} });
    await queueWrite({ entity_type: "Meeting", entity_id: generateId(), op: "create", payload: {} });
    expect(await pendingCount()).toBe(2);
  });

  it("returns 0 for an empty queue", async () => {
    expect(await pendingCount()).toBe(0);
  });
});

describe("cacheList / getCachedList", () => {
  it("caches a list of server records keyed by their id field", async () => {
    await cacheList("Case", [
      { case_id: "case-1", type: "land", status: "open" },
      { case_id: "case-2", type: "family", status: "resolved" },
    ]);

    const cached = await getCachedList("Case");
    expect(cached).toHaveLength(2);
    expect(cached.map((c) => c.case_id).sort()).toEqual(["case-1", "case-2"]);
  });

  it("ignores records missing their id field rather than throwing", async () => {
    await cacheList("Case", [{ type: "land" } as any, { case_id: "case-3", type: "debt" }]);
    const cached = await getCachedList("Case");
    expect(cached).toHaveLength(1);
    expect(cached[0].case_id).toBe("case-3");
  });

  it("getCachedList returns an empty array (not an error) when nothing is cached, so views don't blank out", async () => {
    const cached = await getCachedList("RevenueRecord");
    expect(cached).toEqual([]);
  });
});
