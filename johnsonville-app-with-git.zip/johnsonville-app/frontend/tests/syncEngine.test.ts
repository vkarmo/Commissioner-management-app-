import { describe, it, expect, beforeEach, vi } from "vitest";
import { offlineDb, generateId, queueWrite } from "../src/db/offlineDb";
import { flushQueue, subscribeSyncState } from "../src/db/syncEngine";

beforeEach(async () => {
  await offlineDb.writeQueue.clear();
  await offlineDb.cache.clear();
  vi.restoreAllMocks();
  Object.defineProperty(navigator, "onLine", { value: true, configurable: true });
});

describe("flushQueue", () => {
  it("does nothing when the queue is empty", async () => {
    const fetchSpy = vi.spyOn(global, "fetch");
    await flushQueue();
    expect(fetchSpy).not.toHaveBeenCalled();
  });

  it("does not attempt to sync while offline", async () => {
    Object.defineProperty(navigator, "onLine", { value: false, configurable: true });
    const id = generateId();
    await queueWrite({ entity_type: "Case", entity_id: id, op: "create", payload: { type: "land" } });

    const fetchSpy = vi.spyOn(global, "fetch");
    await flushQueue();
    expect(fetchSpy).not.toHaveBeenCalled();
  });

  it("posts queued items to /api/sync/batch and marks them synced on success", async () => {
    const id = generateId();
    await queueWrite({ entity_type: "Case", entity_id: id, op: "create", payload: { type: "land" } });

    vi.spyOn(global, "fetch").mockResolvedValueOnce({
      ok: true,
      json: async () => ({ results: [{ entity_id: id, status: "applied" }] }),
    } as Response);

    await flushQueue();

    const remaining = await offlineDb.writeQueue.toArray();
    expect(remaining).toHaveLength(0); // synced items are cleared out
  });

  it("sends base_last_edited_at and client_updated_at for conflict detection on the server", async () => {
    const id = generateId();
    await queueWrite({
      entity_type: "Case",
      entity_id: id,
      op: "update",
      payload: { status: "resolved" },
      base_last_edited_at: "2026-08-01T00:00:00.000Z",
    });

    const fetchSpy = vi.spyOn(global, "fetch").mockResolvedValueOnce({
      ok: true,
      json: async () => ({ results: [{ entity_id: id, status: "applied" }] }),
    } as Response);

    await flushQueue();

    const body = JSON.parse((fetchSpy.mock.calls[0][1] as RequestInit).body as string);
    expect(body.items[0]).toMatchObject({
      entity_id: id,
      op: "update",
      base_last_edited_at: "2026-08-01T00:00:00.000Z",
    });
  });

  it("keeps a conflicted item's local record synced but surfaces the conflict via sync state", async () => {
    const id = generateId();
    await queueWrite({ entity_type: "Case", entity_id: id, op: "update", payload: { status: "resolved" } });

    vi.spyOn(global, "fetch").mockResolvedValueOnce({
      ok: true,
      json: async () => ({ results: [{ entity_id: id, status: "conflict" }] }),
    } as Response);

    let latestState: any = null;
    const unsubscribe = subscribeSyncState((s) => (latestState = s));

    await flushQueue();
    unsubscribe();

    expect(latestState.conflictsThisSync).toBe(1);
    const remaining = await offlineDb.writeQueue.toArray();
    expect(remaining).toHaveLength(0); // still applied server-side, just flagged for review there
  });

  it("marks an item as error (and keeps it queued) when the server reports a failure for it", async () => {
    const id = generateId();
    await queueWrite({ entity_type: "Case", entity_id: id, op: "create", payload: { type: "land" } });

    vi.spyOn(global, "fetch").mockResolvedValueOnce({
      ok: true,
      json: async () => ({ results: [{ entity_id: id, status: "error", error: "boom" }] }),
    } as Response);

    await flushQueue();

    const remaining = await offlineDb.writeQueue.toArray();
    expect(remaining).toHaveLength(1);
    expect(remaining[0]).toMatchObject({ status: "error", error: "boom" });
  });

  it("records lastError and leaves items queued when the sync request itself fails", async () => {
    const id = generateId();
    await queueWrite({ entity_type: "Case", entity_id: id, op: "create", payload: { type: "land" } });

    vi.spyOn(global, "fetch").mockResolvedValueOnce({ ok: false, status: 503 } as Response);

    let latestState: any = null;
    const unsubscribe = subscribeSyncState((s) => (latestState = s));
    await flushQueue();
    unsubscribe();

    expect(latestState.lastError).toBeTruthy();
    const remaining = await offlineDb.writeQueue.toArray();
    expect(remaining.length).toBeGreaterThan(0);
  });
});
