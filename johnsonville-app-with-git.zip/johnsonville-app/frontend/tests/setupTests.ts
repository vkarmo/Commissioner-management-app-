import "@testing-library/jest-dom";
import "fake-indexeddb/auto"; // gives jsdom a working IndexedDB for Dexie
