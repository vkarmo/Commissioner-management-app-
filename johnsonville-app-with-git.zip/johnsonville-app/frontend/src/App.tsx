import React from "react";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { AuthProvider, useAuth } from "./auth/AuthContext";
import Layout from "./components/Layout";
import Login from "./pages/Login";
import Dashboard from "./pages/Dashboard";
import CaseList from "./pages/Cases/CaseList";
import NewCase from "./pages/Cases/NewCase";
import CaseDetail from "./pages/Cases/CaseDetail";
import ParcelList from "./pages/Land/ParcelList";
import NewParcel from "./pages/Land/NewParcel";
import ParcelDetail from "./pages/Land/ParcelDetail";
import Registry from "./pages/Registry/Registry";
import Revenue from "./pages/Revenue/Revenue";
import PublicWorks from "./pages/PublicWorks/PublicWorks";
import Communications from "./pages/Communications/Communications";
import Meetings from "./pages/Meetings/Meetings";
import Admin from "./pages/Admin/Admin";

function RequireAuth({ children }: { children: React.ReactElement }) {
  const { user, loading } = useAuth();
  if (loading) return <div className="loading-screen">Loading…</div>;
  if (!user) return <Navigate to="/login" replace />;
  return children;
}

function RequireRole({ roles, children }: { roles: string[]; children: React.ReactElement }) {
  const { user } = useAuth();
  if (!user || !roles.includes(user.role)) return <Navigate to="/" replace />;
  return children;
}

export default function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <Routes>
          <Route path="/login" element={<Login />} />
          <Route
            path="/"
            element={
              <RequireAuth>
                <Layout />
              </RequireAuth>
            }
          >
            <Route index element={<Dashboard />} />
            <Route path="cases" element={<CaseList />} />
            <Route path="cases/new" element={<NewCase />} />
            <Route path="cases/:id" element={<CaseDetail />} />
            <Route path="land" element={<ParcelList />} />
            <Route path="land/new" element={<NewParcel />} />
            <Route path="land/parcels/:id" element={<ParcelDetail />} />
            <Route path="registry" element={<Registry />} />
            <Route path="revenue" element={<Revenue />} />
            <Route path="revenue/new" element={<Revenue />} />
            <Route path="public-works" element={<PublicWorks />} />
            <Route path="public-works/new" element={<PublicWorks />} />
            <Route path="communications" element={<Communications />} />
            <Route path="meetings" element={<Meetings />} />
            <Route
              path="admin"
              element={
                <RequireRole roles={["SuperAdmin", "Commissioner"]}>
                  <Admin />
                </RequireRole>
              }
            />
          </Route>
        </Routes>
      </AuthProvider>
    </BrowserRouter>
  );
}
