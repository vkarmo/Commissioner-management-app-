import { EntityType, generateId, queueWrite, cacheList, getCachedList } from "../db/offlineDb";
import { flushQueue } from "../db/syncEngine";

async function request(path: string, init?: RequestInit) {
  const res = await fetch(`/api${path}`, {
    credentials: "include",
    headers: { "Content-Type": "application/json" },
    ...init,
  });
  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    throw new Error(body.error || `Request failed: ${res.status}`);
  }
  return res.json();
}

/** GET a list, caching the result for offline use. If the network request
 * fails (offline or AuraDB waking up + timing out), falls back to cache
 * rather than showing a blank screen. */
export async function fetchList(
  path: string,
  entity_type: EntityType,
  listKey: string
): Promise<{ items: Record<string, any>[]; fromCache: boolean }> {
  try {
    const data = await request(path);
    const items = data[listKey] || [];
    await cacheList(entity_type, items);
    return { items, fromCache: false };
  } catch {
    const items = await getCachedList(entity_type);
    return { items, fromCache: true };
  }
}

/** Create a record. Online: POST immediately. Offline: queue it locally
 * with a client-generated UUID and sync later. Either way the caller gets
 * the entity_id back right away so the UI can navigate to it. */
export async function createRecord(
  apiPath: string,
  entity_type: EntityType,
  payload: Record<string, any>,
  idField: string
): Promise<string> {
  const id = payload[idField] || generateId();
  const fullPayload = { ...payload, [idField]: id };

  if (navigator.onLine) {
    try {
      await request(apiPath, { method: "POST", body: JSON.stringify(fullPayload) });
      return id;
    } catch {
      // fall through to offline queue if the request failed mid-flight
    }
  }

  await queueWrite({ entity_type, entity_id: id, op: "create", payload: fullPayload });
  return id;
}

export async function updateRecord(
  entity_type: EntityType,
  entity_id: string,
  payload: Record<string, any>,
  base_last_edited_at: string | null
): Promise<void> {
  await queueWrite({ entity_type, entity_id, op: "update", payload, base_last_edited_at });
  if (navigator.onLine) flushQueue();
}

export { request };
