/**
 * Resizes and compresses a photo before it ever touches IndexedDB or the
 * network — required per the build spec to stay within practical IndexedDB
 * storage limits on low-end Android devices and to keep sync payloads
 * small on 2G/3G. Returns a base64 data URL (stored as photo_ref).
 */
export async function compressPhoto(
  file: File,
  maxDimension = 1024,
  quality = 0.7
): Promise<string> {
  const bitmap = await createImageBitmap(file);
  const scale = Math.min(1, maxDimension / Math.max(bitmap.width, bitmap.height));
  const width = Math.round(bitmap.width * scale);
  const height = Math.round(bitmap.height * scale);

  const canvas = document.createElement("canvas");
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext("2d");
  if (!ctx) throw new Error("Canvas not supported");
  ctx.drawImage(bitmap, 0, 0, width, height);

  return new Promise((resolve, reject) => {
    canvas.toBlob(
      (blob) => {
        if (!blob) return reject(new Error("Compression failed"));
        const reader = new FileReader();
        reader.onload = () => resolve(reader.result as string);
        reader.onerror = reject;
        reader.readAsDataURL(blob);
      },
      "image/jpeg",
      quality
    );
  });
}
