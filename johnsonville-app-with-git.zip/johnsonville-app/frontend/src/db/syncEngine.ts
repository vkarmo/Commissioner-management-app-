import { offlineDb } from "./offlineDb";

type SyncListener = (state: SyncState) => void;

export interface SyncState {
  isOnline: boolean;
  pending: number;
  syncing: boolean;
  lastSyncAt: string | null;
  lastError: string | null;
  conflictsThisSync: number;
}

let state: SyncState = {
  isOnline: navigator.onLine,
  pending: 0,
  syncing: false,
  lastSyncAt: null,
  lastError: null,
  conflictsThisSync: 0,
};

const listeners = new Set<SyncListener>();

function emit() {
  listeners.forEach((l) => l(state));
}

export function subscribeSyncState(listener: SyncListener): () => void {
  listeners.add(listener);
  listener(state);
  return () => listeners.delete(listener);
}

async function refreshPendingCount() {
  const pending = await offlineDb.writeQueue.where("status").anyOf(["pending", "error"]).count();
  state = { ...state, pending };
  emit();
}

/**
 * Sends everything in the write queue to /api/sync/batch. Applies
 * last-write-wins server-side but surfaces any flagged conflicts back to
 * the clerk rather than pretending the sync was clean.
 */
export async function flushQueue(): Promise<void> {
  if (state.syncing || !navigator.onLine) return;

  const items = await offlineDb.writeQueue.where("status").anyOf(["pending", "error"]).toArray();
  if (items.length === 0) {
    state = { ...state, pending: 0 };
    emit();
    return;
  }

  state = { ...state, syncing: true };
  emit();

  try {
    await offlineDb.writeQueue.where("id").anyOf(items.map((i) => i.id!)).modify({ status: "syncing" });

    const res = await fetch("/api/sync/batch", {
      method: "POST",
      credentials: "include",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        items: items.map((i) => ({
          entity_type: i.entity_type,
          entity_id: i.entity_id,
          op: i.op,
          payload: i.payload,
          base_last_edited_at: i.base_last_edited_at,
          client_updated_at: i.client_updated_at,
        })),
      }),
    });

    if (!res.ok) {
      throw new Error(`Sync request failed with status ${res.status}`);
    }

    const { results } = (await res.json()) as {
      results: { entity_id: string; status: "applied" | "conflict" | "error"; error?: string }[];
    };

    let conflicts = 0;
    for (let idx = 0; idx < items.length; idx++) {
      const item = items[idx];
      const result = results[idx];
      if (!result) continue;

      if (result.status === "applied" || result.status === "conflict") {
        if (result.status === "conflict") conflicts += 1;
        await offlineDb.writeQueue.update(item.id!, { status: "synced" });
      } else {
        await offlineDb.writeQueue.update(item.id!, { status: "error", error: result.error });
      }
    }

    // Clear out fully synced items to keep the queue table small.
    await offlineDb.writeQueue.where("status").equals("synced").delete();

    state = {
      ...state,
      syncing: false,
      lastSyncAt: new Date().toISOString(),
      lastError: null,
      conflictsThisSync: conflicts,
    };
  } catch (err: any) {
    state = { ...state, syncing: false, lastError: err.message || "Sync failed" };
  } finally {
    await refreshPendingCount();
  }
}

export function initSyncEngine() {
  refreshPendingCount();

  window.addEventListener("online", () => {
    state = { ...state, isOnline: true };
    emit();
    flushQueue();
  });
  window.addEventListener("offline", () => {
    state = { ...state, isOnline: false };
    emit();
  });

  // Also retry periodically in case 'online' fires before the network is
  // actually usable (common on flaky 2G/3G handoffs).
  setInterval(() => {
    if (navigator.onLine) flushQueue();
  }, 30_000);

  if (navigator.onLine) flushQueue();
}
