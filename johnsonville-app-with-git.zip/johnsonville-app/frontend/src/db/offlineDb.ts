import Dexie, { Table } from "dexie";

/**
 * Every record created client-side gets its ID here (uuid), matching the
 * backend's client-generatable UUID primary keys. This is what lets a
 * clerk file a case AND add a new person as the filer while fully offline,
 * in one screen, and have both sync together as a consistent batch later —
 * neither ID depends on a server round-trip.
 */
export function generateId(): string {
  // crypto.randomUUID is available in all modern mobile browsers targeted
  // here (Chrome/WebView on Android); fallback included for safety.
  if (typeof crypto !== "undefined" && "randomUUID" in crypto) {
    return crypto.randomUUID();
  }
  return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, (c) => {
    const r = (Math.random() * 16) | 0;
    const v = c === "x" ? r : (r & 0x3) | 0x8;
    return v.toString(16);
  });
}

export type EntityType =
  | "Case"
  | "Person"
  | "Parcel"
  | "RevenueRecord"
  | "PublicWorksItem"
  | "CommunicationLog"
  | "Meeting";

export interface QueuedWrite {
  id?: number; // Dexie auto-increment local queue id
  entity_type: EntityType;
  entity_id: string; // client-generated UUID, matches backend node id
  op: "create" | "update";
  payload: Record<string, any>;
  base_last_edited_at: string | null; // for conflict detection
  client_updated_at: string;
  status: "pending" | "syncing" | "synced" | "error";
  error?: string;
}

export interface CachedRecord {
  cache_key: string; // `${entity_type}:${entity_id}`
  entity_type: EntityType;
  entity_id: string;
  data: Record<string, any>;
  cached_at: string;
}

class OfflineDatabase extends Dexie {
  writeQueue!: Table<QueuedWrite, number>;
  cache!: Table<CachedRecord, string>;

  constructor() {
    super("johnsonville_offline_db");
    this.version(1).stores({
      // ++id = auto-increment local key; status indexed for the sync engine
      writeQueue: "++id, entity_type, entity_id, status",
      // cache_key is the primary key so upserts are simple
      cache: "cache_key, entity_type, entity_id",
    });
  }
}

export const offlineDb = new OfflineDatabase();

/** Queue a create/update for later sync, and immediately update the local
 * cache so list/detail views reflect the change even before syncing. */
export async function queueWrite(params: {
  entity_type: EntityType;
  entity_id: string;
  op: "create" | "update";
  payload: Record<string, any>;
  base_last_edited_at?: string | null;
}) {
  const now = new Date().toISOString();
  await offlineDb.writeQueue.add({
    entity_type: params.entity_type,
    entity_id: params.entity_id,
    op: params.op,
    payload: params.payload,
    base_last_edited_at: params.base_last_edited_at ?? null,
    client_updated_at: now,
    status: "pending",
  });

  const cacheKey = `${params.entity_type}:${params.entity_id}`;
  const existing = await offlineDb.cache.get(cacheKey);
  await offlineDb.cache.put({
    cache_key: cacheKey,
    entity_type: params.entity_type,
    entity_id: params.entity_id,
    data: { ...(existing?.data || {}), ...params.payload, [idPropFor(params.entity_type)]: params.entity_id },
    cached_at: now,
  });
}

function idPropFor(type: EntityType): string {
  const map: Record<EntityType, string> = {
    Case: "case_id",
    Person: "person_id",
    Parcel: "parcel_id",
    RevenueRecord: "revenue_id",
    PublicWorksItem: "public_works_id",
    CommunicationLog: "comm_id",
    Meeting: "meeting_id",
  };
  return map[type];
}

export async function pendingCount(): Promise<number> {
  return offlineDb.writeQueue.where("status").equals("pending").count();
}

export async function cacheList(entity_type: EntityType, records: Record<string, any>[]) {
  const now = new Date().toISOString();
  const idProp = idPropFor(entity_type);
  await offlineDb.cache.bulkPut(
    records
      .filter((r) => r[idProp])
      .map((r) => ({
        cache_key: `${entity_type}:${r[idProp]}`,
        entity_type,
        entity_id: r[idProp],
        data: r,
        cached_at: now,
      }))
  );
}

export async function getCachedList(entity_type: EntityType): Promise<Record<string, any>[]> {
  const rows = await offlineDb.cache.where("entity_type").equals(entity_type).toArray();
  return rows.map((r) => r.data);
}
