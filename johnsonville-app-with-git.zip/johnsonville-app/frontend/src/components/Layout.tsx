import React from "react";
import { NavLink, Outlet } from "react-router-dom";
import { useAuth, hasRole } from "../auth/AuthContext";
import SyncStatusBadge from "./SyncStatusBadge";

export default function Layout() {
  const { user, logout } = useAuth();
  const isClerk = user?.role === "Clerk";

  return (
    <div className="app-shell">
      <header className="app-header">
        <div className="app-header-title">Johnsonville Commissioner's Office</div>
        <SyncStatusBadge />
        <div className="app-header-user">
          <span>{user?.name}</span>
          <button className="link-btn" onClick={logout}>
            Sign out
          </button>
        </div>
      </header>

      <nav className="app-nav">
        <NavLink to="/" end>
          {isClerk ? "My Tasks" : "Dashboard"}
        </NavLink>
        <NavLink to="/cases">Cases</NavLink>
        <NavLink to="/land">Land Records</NavLink>
        {!isClerk && <NavLink to="/registry">Registry</NavLink>}
        <NavLink to="/revenue">Revenue</NavLink>
        <NavLink to="/public-works">Public Works</NavLink>
        {!isClerk && <NavLink to="/communications">Communications</NavLink>}
        <NavLink to="/meetings">Meetings</NavLink>
        {hasRole(user, "SuperAdmin", "Commissioner") && <NavLink to="/admin">Admin</NavLink>}
      </nav>

      <main className="app-content">
        <Outlet />
      </main>
    </div>
  );
}
