import React, { useEffect, useState } from "react";
import { subscribeSyncState, SyncState } from "../db/syncEngine";

export default function SyncStatusBadge() {
  const [state, setState] = useState<SyncState | null>(null);

  useEffect(() => subscribeSyncState(setState), []);

  if (!state) return null;

  if (!state.isOnline) {
    return (
      <span className="sync-badge sync-badge-offline">
        Offline{state.pending > 0 ? ` — ${state.pending} record${state.pending === 1 ? "" : "s"} pending sync` : ""}
      </span>
    );
  }

  if (state.syncing) {
    return <span className="sync-badge sync-badge-syncing">Syncing…</span>;
  }

  if (state.pending > 0) {
    return (
      <span className="sync-badge sync-badge-pending">
        {state.pending} record{state.pending === 1 ? "" : "s"} pending sync
      </span>
    );
  }

  return <span className="sync-badge sync-badge-ok">All synced</span>;
}
