import React, { useMemo } from "react";
import { MapContainer, TileLayer, Polygon, Popup, Marker } from "react-leaflet";
import "leaflet/dist/leaflet.css";

interface ParcelMapProps {
  /** GeoJSON geometry (Polygon or MultiPolygon), or null if not on file. */
  geometry: any | null;
  parcelId: string;
  /** Adjacent parcels with their own geometry, if available, shown as
   * context around the main parcel. */
  adjacent?: { parcel_id: string; geometry: any | null }[];
}

// Fallback center: Johnsonville, Liberia (approximate) — used only when a
// parcel has no geometry on file yet, so the map still renders something
// useful rather than erroring.
const FALLBACK_CENTER: [number, number] = [6.328, -10.797];

function geoJsonPolygonToLatLngs(geometry: any): [number, number][][] | null {
  if (!geometry || !geometry.coordinates) return null;
  try {
    if (geometry.type === "Polygon") {
      return geometry.coordinates.map((ring: number[][]) => ring.map(([lng, lat]) => [lat, lng]));
    }
    if (geometry.type === "MultiPolygon") {
      // Flatten to first polygon for simplicity — most district land
      // records are single simple polygons.
      return geometry.coordinates[0].map((ring: number[][]) => ring.map(([lng, lat]) => [lat, lng]));
    }
  } catch {
    return null;
  }
  return null;
}

function polygonCentroid(latlngs: [number, number][][]): [number, number] {
  const points = latlngs[0] || [];
  if (points.length === 0) return FALLBACK_CENTER;
  const [sumLat, sumLng] = points.reduce(
    ([lat, lng], [pLat, pLng]) => [lat + pLat, lng + pLng],
    [0, 0]
  );
  return [sumLat / points.length, sumLng / points.length];
}

export default function ParcelMap({ geometry, parcelId, adjacent = [] }: ParcelMapProps) {
  const mainLatLngs = useMemo(() => geoJsonPolygonToLatLngs(geometry), [geometry]);
  const center = mainLatLngs ? polygonCentroid(mainLatLngs) : FALLBACK_CENTER;

  if (!geometry) {
    return (
      <div className="map-placeholder">
        No boundary geometry on file for this parcel yet. Once GeoJSON coordinates are recorded, they'll
        appear here.
      </div>
    );
  }

  return (
    <div className="map-wrapper">
      <MapContainer center={center} zoom={17} style={{ height: 320, width: "100%", borderRadius: 10 }}>
        <TileLayer
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        />
        {mainLatLngs && (
          <Polygon positions={mainLatLngs} pathOptions={{ color: "#0b3d2e", weight: 3, fillOpacity: 0.25 }}>
            <Popup>Parcel {parcelId.slice(0, 8)}…</Popup>
          </Polygon>
        )}
        {adjacent.map((a) => {
          const ll = geoJsonPolygonToLatLngs(a.geometry);
          if (!ll) return null;
          return (
            <Polygon
              key={a.parcel_id}
              positions={ll}
              pathOptions={{ color: "#8a5a00", weight: 2, fillOpacity: 0.1, dashArray: "4" }}
            >
              <Popup>Adjacent parcel {a.parcel_id.slice(0, 8)}…</Popup>
            </Polygon>
          );
        })}
      </MapContainer>
      <p className="fineprint">
        Map tiles use OpenStreetMap. Tiles require connectivity to load; boundary shapes above still render
        from cached parcel data when offline, just without the base map imagery.
      </p>
    </div>
  );
}
