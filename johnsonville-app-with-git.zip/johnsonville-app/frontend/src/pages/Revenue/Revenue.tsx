import React, { useEffect, useState } from "react";
import { fetchList, createRecord, request } from "../../api/client";

export default function Revenue() {
  const [records, setRecords] = useState<any[]>([]);
  const [summary, setSummary] = useState<any[]>([]);
  const [quarters, setQuarters] = useState<any[]>([]);
  const [fromCache, setFromCache] = useState(false);

  const [amount, setAmount] = useState("");
  const [revType, setRevType] = useState("market_due");
  const [quarterId, setQuarterId] = useState("");
  const [submitting, setSubmitting] = useState(false);

  const load = () => {
    fetchList("/revenue", "RevenueRecord", "records").then((r) => {
      setRecords(r.items);
      setFromCache(r.fromCache);
    });
    request("/revenue/summary").then((d) => setSummary(d.summary)).catch(() => {});
    request("/registry/quarters").then((d) => setQuarters(d.quarters)).catch(() => {});
  };

  useEffect(load, []);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    await createRecord(
      "/revenue",
      "RevenueRecord",
      { amount: parseFloat(amount), type: revType, quarter_id: quarterId || undefined },
      "revenue_id"
    );
    setAmount("");
    setSubmitting(false);
    load();
  };

  return (
    <div>
      <h1>Revenue &amp; Market Management</h1>
      {fromCache && <div className="alert alert-warning">Showing cached results — offline.</div>}

      <form className="form form-inline" onSubmit={submit}>
        <select value={revType} onChange={(e) => setRevType(e.target.value)}>
          <option value="market_due">Market due</option>
          <option value="permit_fee">Permit fee</option>
          <option value="levy">Levy</option>
        </select>
        <input
          type="number"
          step="0.01"
          placeholder="Amount ($)"
          value={amount}
          onChange={(e) => setAmount(e.target.value)}
          required
        />
        <select value={quarterId} onChange={(e) => setQuarterId(e.target.value)}>
          <option value="">Quarter</option>
          {quarters.map((q) => (
            <option key={q.quarter_id} value={q.quarter_id}>
              {q.name}
            </option>
          ))}
        </select>
        <button type="submit" className="btn btn-primary" disabled={submitting}>
          Log collection
        </button>
      </form>

      <h2>Monthly summary</h2>
      <table className="table">
        <thead>
          <tr>
            <th>Quarter</th>
            <th>Collector</th>
            <th>Total</th>
            <th># Records</th>
          </tr>
        </thead>
        <tbody>
          {summary.map((s, i) => (
            <tr key={i}>
              <td>{s.quarter_name || "—"}</td>
              <td>{s.collector || "—"}</td>
              <td>${Number(s.total || 0).toFixed(2)}</td>
              <td>{s.record_count}</td>
            </tr>
          ))}
        </tbody>
      </table>

      <h2>Recent records</h2>
      <ul className="list">
        {records.map((r) => (
          <li key={r.revenue_id}>
            {r.date} — {r.type} — ${Number(r.amount).toFixed(2)} — {r.quarter_name || "—"} — {r.collector}
          </li>
        ))}
      </ul>
    </div>
  );
}
