import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { request, updateRecord } from "../../api/client";

const STATUSES = ["intake_pending", "open", "mediation", "resolved", "referred"];

export default function CaseDetail() {
  const { id } = useParams<{ id: string }>();
  const [data, setData] = useState<any>(null);
  const [error, setError] = useState<string | null>(null);

  const load = () => {
    if (!id) return;
    request(`/cases/${id}`)
      .then(setData)
      .catch(() => setError("Couldn't load full case detail — you may be offline. Basic info may still be cached."));
  };

  useEffect(load, [id]);

  const changeStatus = async (status: string) => {
    if (!id || !data) return;
    await updateRecord("Case", id, { status }, data.case.last_edited_at);
    setData({ ...data, case: { ...data.case, status } });
  };

  if (!data) return <div>{error || "Loading…"}</div>;

  const { case: c, quarter_name, filers, named_parties, hearings, disputed_parcels } = data;

  return (
    <div>
      <h1>
        {c.type} case — <span className={`badge badge-${c.status}`}>{c.status?.replace("_", " ")}</span>
      </h1>
      {error && <div className="alert alert-warning">{error}</div>}

      <div className="detail-grid">
        <div>
          <strong>Quarter:</strong> {quarter_name || "—"}
        </div>
        <div>
          <strong>Filed:</strong> {c.filed_date}
        </div>
      </div>

      <p>{c.summary}</p>

      <label>
        Update status
        <select value={c.status} onChange={(e) => changeStatus(e.target.value)}>
          {STATUSES.map((s) => (
            <option key={s} value={s}>
              {s.replace("_", " ")}
            </option>
          ))}
        </select>
      </label>

      <h3>Complainant(s)</h3>
      <ul className="list">
        {(filers || []).filter((f: any) => f.name).map((f: any, i: number) => (
          <li key={i}>
            {f.name} {f.phone && `— ${f.phone}`}
          </li>
        ))}
      </ul>

      <h3>Named parties</h3>
      <ul className="list">
        {(named_parties || []).filter((p: any) => p.name).map((p: any, i: number) => (
          <li key={i}>
            {p.name} ({p.role})
          </li>
        ))}
      </ul>

      {disputed_parcels && disputed_parcels.length > 0 && (
        <>
          <h3>Linked land parcels in dispute</h3>
          <ul className="list">
            {disputed_parcels.map((pid: string) => (
              <li key={pid}>
                <a href={`/land/parcels/${pid}`}>{pid}</a>
              </li>
            ))}
          </ul>
        </>
      )}

      <h3>Hearings</h3>
      <ul className="list">
        {(hearings || []).filter((h: any) => h.hearing).map((h: any, i: number) => (
          <li key={i}>
            {h.hearing.properties.date} at {h.hearing.properties.location || "TBD"} — presided by{" "}
            {h.official || "unassigned"}
            {h.hearing.properties.outcome_notes && <div>Outcome: {h.hearing.properties.outcome_notes}</div>}
          </li>
        ))}
        {(!hearings || hearings.filter((h: any) => h.hearing).length === 0) && <li>No hearings scheduled yet.</li>}
      </ul>
    </div>
  );
}
