import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { fetchList } from "../../api/client";

const STATUSES = ["intake_pending", "open", "mediation", "resolved", "referred"];
const TYPES = ["land", "family", "debt", "chieftaincy", "criminal-referral", "other"];

export default function CaseList() {
  const [cases, setCases] = useState<any[]>([]);
  const [status, setStatus] = useState("");
  const [type, setType] = useState("");
  const [fromCache, setFromCache] = useState(false);

  const load = () => {
    const params = new URLSearchParams();
    if (status) params.set("status", status);
    if (type) params.set("type", type);
    fetchList(`/cases?${params.toString()}`, "Case", "cases").then((r) => {
      setCases(r.items);
      setFromCache(r.fromCache);
    });
  };

  useEffect(load, [status, type]);

  return (
    <div>
      <div className="page-header">
        <h1>Cases</h1>
        <Link to="/cases/new" className="btn btn-primary">
          + File new case
        </Link>
      </div>

      {fromCache && (
        <div className="alert alert-warning">Showing cached results — you appear to be offline.</div>
      )}

      <div className="filter-row">
        <select value={status} onChange={(e) => setStatus(e.target.value)}>
          <option value="">All statuses</option>
          {STATUSES.map((s) => (
            <option key={s} value={s}>
              {s.replace("_", " ")}
            </option>
          ))}
        </select>
        <select value={type} onChange={(e) => setType(e.target.value)}>
          <option value="">All types</option>
          {TYPES.map((t) => (
            <option key={t} value={t}>
              {t}
            </option>
          ))}
        </select>
      </div>

      <ul className="list">
        {cases.map((c) => (
          <li key={c.case_id} className="list-item">
            <Link to={`/cases/${c.case_id}`}>
              <span className={`badge badge-${c.status}`}>{c.status?.replace("_", " ")}</span>
              <strong>{c.type}</strong> — {c.summary?.slice(0, 60) || "No summary"}
              <div className="list-item-meta">
                {c.quarter_name || "Unassigned quarter"} · filed {c.filed_date}
              </div>
            </Link>
          </li>
        ))}
        {cases.length === 0 && <li>No cases found.</li>}
      </ul>
    </div>
  );
}
