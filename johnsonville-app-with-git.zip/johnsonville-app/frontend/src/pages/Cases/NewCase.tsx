import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { createRecord, request } from "../../api/client";
import { generateId } from "../../db/offlineDb";

const TYPES = ["land", "family", "debt", "chieftaincy", "criminal-referral", "other"];

export default function NewCase() {
  const navigate = useNavigate();
  const [quarters, setQuarters] = useState<any[]>([]);
  const [type, setType] = useState("land");
  const [summary, setSummary] = useState("");
  const [quarterId, setQuarterId] = useState("");
  const [filerName, setFilerName] = useState("");
  const [filerPhone, setFilerPhone] = useState("");
  const [respondentName, setRespondentName] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [savedOffline, setSavedOffline] = useState(false);

  useEffect(() => {
    request("/registry/quarters")
      .then((d) => setQuarters(d.quarters))
      .catch(() => setQuarters([])); // offline on first load — dropdown just empty, still submittable
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);

    const wasOnline = navigator.onLine;
    const caseId = await createRecord(
      "/cases",
      "Case",
      {
        type,
        summary,
        quarter_id: quarterId || undefined,
        filer_name: filerName,
        filer_phone: filerPhone,
        filer_person_id: generateId(),
        named_parties: respondentName ? [{ person_id: generateId(), name: respondentName, role: "respondent" }] : [],
      },
      "case_id"
    );

    setSubmitting(false);
    if (!wasOnline) {
      setSavedOffline(true);
      setTimeout(() => navigate("/cases"), 1200);
    } else {
      navigate(`/cases/${caseId}`);
    }
  };

  return (
    <div>
      <h1>File New Case</h1>
      {savedOffline && (
        <div className="alert alert-warning">
          Saved offline — this case will sync automatically once you're back online.
        </div>
      )}

      <form className="form" onSubmit={handleSubmit}>
        <label>
          Case type
          <select value={type} onChange={(e) => setType(e.target.value)} required>
            {TYPES.map((t) => (
              <option key={t} value={t}>
                {t}
              </option>
            ))}
          </select>
        </label>

        <label>
          Quarter
          <select value={quarterId} onChange={(e) => setQuarterId(e.target.value)}>
            <option value="">Select quarter</option>
            {quarters.map((q) => (
              <option key={q.quarter_id} value={q.quarter_id}>
                {q.name}
              </option>
            ))}
          </select>
        </label>

        <label>
          Summary
          <textarea value={summary} onChange={(e) => setSummary(e.target.value)} rows={4} required />
        </label>

        <fieldset>
          <legend>Person filing (complainant)</legend>
          <label>
            Name
            <input value={filerName} onChange={(e) => setFilerName(e.target.value)} required />
          </label>
          <label>
            Phone
            <input value={filerPhone} onChange={(e) => setFilerPhone(e.target.value)} inputMode="tel" />
          </label>
        </fieldset>

        <fieldset>
          <legend>Respondent (optional)</legend>
          <label>
            Name
            <input value={respondentName} onChange={(e) => setRespondentName(e.target.value)} />
          </label>
        </fieldset>

        <button type="submit" className="btn btn-primary btn-large" disabled={submitting}>
          {submitting ? "Saving…" : "File Case"}
        </button>
      </form>
    </div>
  );
}
