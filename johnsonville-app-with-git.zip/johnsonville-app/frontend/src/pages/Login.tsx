import React from "react";
import { useSearchParams } from "react-router-dom";

const ERROR_MESSAGES: Record<string, string> = {
  not_authorized: "This Google account is not authorized. Contact the Commissioner's office to be added.",
  no_email: "Google did not return an email address for that account.",
  oauth_failed: "Sign-in failed. Please try again.",
  missing_code: "Sign-in was interrupted. Please try again.",
};

export default function Login() {
  const [params] = useSearchParams();
  const errorCode = params.get("error");
  const message = params.get("message") || (errorCode ? ERROR_MESSAGES[errorCode] : null);

  return (
    <div className="login-screen">
      <div className="login-card">
        <h1>Johnsonville Commissioner's Office</h1>
        <p className="subtitle">Case, land, and civic records</p>

        {message && <div className="alert alert-error">{message}</div>}

        <a className="btn btn-google" href="/api/auth/google">
          Sign in with Google
        </a>

        <p className="fineprint">
          Access is limited to Gmail accounts approved by the Commissioner's office.
        </p>
      </div>
    </div>
  );
}
