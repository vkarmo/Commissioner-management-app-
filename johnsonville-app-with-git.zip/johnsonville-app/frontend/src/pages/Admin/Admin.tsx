import React, { useEffect, useState } from "react";
import { useAuth } from "../../auth/AuthContext";
import { request } from "../../api/client";

const ROLES = ["Commissioner", "Clerk", "Official", "SuperAdmin"];

function WhitelistPanel() {
  const [whitelist, setWhitelist] = useState<any[]>([]);
  const [email, setEmail] = useState("");
  const [role, setRole] = useState("Clerk");
  const [error, setError] = useState<string | null>(null);

  const load = () =>
    request("/admin/whitelist")
      .then((d) => setWhitelist(d.whitelist))
      .catch(() => setError("Could not load whitelist — you may be offline. Whitelist changes require connectivity."));

  useEffect(load, []);

  const addEmail = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    try {
      await request("/admin/whitelist", { method: "POST", body: JSON.stringify({ email, role }) });
      setEmail("");
      load();
    } catch (err: any) {
      setError(err.message);
    }
  };

  const toggleActive = async (w: any) => {
    await request(`/admin/whitelist/${encodeURIComponent(w.email)}`, {
      method: "PATCH",
      body: JSON.stringify({ active: !w.active }),
    });
    load();
  };

  const changeRole = async (w: any, newRole: string) => {
    await request(`/admin/whitelist/${encodeURIComponent(w.email)}`, {
      method: "PATCH",
      body: JSON.stringify({ role: newRole }),
    });
    load();
  };

  const remove = async (w: any) => {
    if (!confirm(`Remove ${w.email} from the whitelist?`)) return;
    await request(`/admin/whitelist/${encodeURIComponent(w.email)}`, { method: "DELETE" });
    load();
  };

  return (
    <div className="admin-panel">
      <h2>Manage Whitelist</h2>
      <p className="fineprint">
        Only Gmail accounts listed here can sign in. Changes take effect immediately and require connectivity.
      </p>
      {error && <div className="alert alert-warning">{error}</div>}

      <form className="form form-inline" onSubmit={addEmail}>
        <input
          type="email"
          placeholder="name@gmail.com"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          required
        />
        <select value={role} onChange={(e) => setRole(e.target.value)}>
          {ROLES.map((r) => (
            <option key={r} value={r}>
              {r}
            </option>
          ))}
        </select>
        <button type="submit" className="btn btn-primary">
          Add
        </button>
      </form>

      <table className="table">
        <thead>
          <tr>
            <th>Email</th>
            <th>Role</th>
            <th>Active</th>
            <th>Added by</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          {whitelist.map((w) => (
            <tr key={w.email}>
              <td>{w.email}</td>
              <td>
                <select value={w.role} onChange={(e) => changeRole(w, e.target.value)}>
                  {ROLES.map((r) => (
                    <option key={r} value={r}>
                      {r}
                    </option>
                  ))}
                </select>
              </td>
              <td>
                <button className="link-btn" onClick={() => toggleActive(w)}>
                  {w.active ? "Active" : "Disabled"}
                </button>
              </td>
              <td>{w.added_by}</td>
              <td>
                <button className="link-btn link-btn-danger" onClick={() => remove(w)}>
                  Remove
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function UsagePanel() {
  const [usage, setUsage] = useState<any>(null);

  useEffect(() => {
    request("/admin/db-usage").then(setUsage).catch(() => {});
  }, []);

  if (!usage) return null;

  return (
    <div className="admin-panel">
      <h2>AuraDB Free Usage</h2>
      {usage.warning && <div className="alert alert-error">{usage.warning}</div>}
      <div className="usage-bars">
        <div>
          <div className="usage-label">
            Nodes: {usage.nodeCount.toLocaleString()} / {usage.nodeCap.toLocaleString()}
          </div>
          <div className="usage-bar">
            <div
              className="usage-bar-fill"
              style={{ width: `${Math.min(100, usage.nodePct * 100)}%` }}
            />
          </div>
        </div>
        <div>
          <div className="usage-label">
            Relationships: {usage.relCount.toLocaleString()} / {usage.relCap.toLocaleString()}
          </div>
          <div className="usage-bar">
            <div
              className="usage-bar-fill"
              style={{ width: `${Math.min(100, usage.relPct * 100)}%` }}
            />
          </div>
        </div>
      </div>
      <p className="fineprint">
        AuraDB Free caps at roughly 200K nodes / 400K relationships and auto-pauses when idle. Plan an
        upgrade to a paid Aura tier or self-hosted Neo4j well before reaching these limits.
      </p>
    </div>
  );
}

function SyncConflictsPanel() {
  const [conflicts, setConflicts] = useState<any[]>([]);

  const load = () => request("/admin/sync-conflicts").then((d) => setConflicts(d.conflicts)).catch(() => {});
  useEffect(load, []);

  const resolve = async (id: string, resolution: string) => {
    await request(`/admin/sync-conflicts/${id}/resolve`, {
      method: "POST",
      body: JSON.stringify({ resolution }),
    });
    load();
  };

  return (
    <div className="admin-panel">
      <h2>Sync Conflicts Needing Review</h2>
      <p className="fineprint">
        These records were edited both offline and on the server before syncing. The most recent write was
        applied automatically, but review each to confirm nothing important was lost.
      </p>
      {conflicts.length === 0 && <p>No conflicts pending review.</p>}
      <ul className="list">
        {conflicts.map((c) => (
          <li key={c.conflict_id} className="list-item">
            <div>
              <strong>{c.entity_type}</strong> {c.entity_id.slice(0, 8)}… — reported by {c.reported_by}
            </div>
            <pre className="conflict-payload">{c.client_payload}</pre>
            <div className="conflict-actions">
              <button className="btn" onClick={() => resolve(c.conflict_id, "kept_server")}>
                Kept server version
              </button>
              <button className="btn" onClick={() => resolve(c.conflict_id, "manual")}>
                Reviewed / resolved manually
              </button>
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
}

function AuditLogPanel() {
  const [events, setEvents] = useState<any[]>([]);

  useEffect(() => {
    request("/admin/audit-log?limit=100").then((d) => setEvents(d.events)).catch(() => {});
  }, []);

  return (
    <div className="admin-panel">
      <h2>Audit Log</h2>
      <table className="table">
        <thead>
          <tr>
            <th>When</th>
            <th>Actor</th>
            <th>Action</th>
            <th>Entity</th>
            <th>Details</th>
          </tr>
        </thead>
        <tbody>
          {events.map((e) => (
            <tr key={e.audit_id}>
              <td>{String(e.at).slice(0, 19).replace("T", " ")}</td>
              <td>{e.actor_email}</td>
              <td>{e.action}</td>
              <td>
                {e.entity_label} {String(e.entity_id).slice(0, 8)}…
              </td>
              <td>{e.details}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default function Admin() {
  const { user } = useAuth();
  const isSuperAdmin = user?.role === "SuperAdmin";

  return (
    <div>
      <h1>Admin</h1>
      {isSuperAdmin && <WhitelistPanel />}
      <UsagePanel />
      <SyncConflictsPanel />
      {isSuperAdmin && <AuditLogPanel />}
    </div>
  );
}
