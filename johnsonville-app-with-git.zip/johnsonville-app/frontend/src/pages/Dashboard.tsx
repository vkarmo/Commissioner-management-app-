import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { useAuth } from "../auth/AuthContext";
import { request } from "../api/client";

export default function Dashboard() {
  const { user } = useAuth();
  const isClerk = user?.role === "Clerk";
  const [summary, setSummary] = useState<any>(null);
  const [myTasks, setMyTasks] = useState<any>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const path = isClerk ? "/dashboard/my-tasks" : "/dashboard/summary";
    request(path)
      .then(isClerk ? setMyTasks : setSummary)
      .catch(() => setError("Could not load dashboard data. Showing cached info where available."));
  }, [isClerk]);

  if (isClerk) {
    return (
      <div>
        <h1>My Tasks</h1>
        {error && <div className="alert alert-warning">{error}</div>}
        <div className="card-grid">
          <Link to="/cases/new" className="action-card">
            + File a new case
          </Link>
          <Link to="/public-works/new" className="action-card">
            + Log a public works issue
          </Link>
          <Link to="/revenue/new" className="action-card">
            + Record revenue collected
          </Link>
        </div>
        <h2>My open cases</h2>
        <ul className="list">
          {(myTasks?.myOpenCases || []).map((c: any) => (
            <li key={c.case_id}>
              <Link to={`/cases/${c.case_id}`}>
                {c.type} — {c.status} — filed {c.filed_date}
              </Link>
            </li>
          ))}
          {myTasks && myTasks.myOpenCases.length === 0 && <li>No open cases assigned to you.</li>}
        </ul>
      </div>
    );
  }

  return (
    <div>
      <h1>Dashboard</h1>
      {error && <div className="alert alert-warning">{error}</div>}
      <div className="stat-grid">
        <div className="stat-card">
          <div className="stat-value">{summary?.openCaseCount ?? "—"}</div>
          <div className="stat-label">Open cases</div>
        </div>
        <div className="stat-card">
          <div className="stat-value">{summary?.pendingLandDisputes ?? "—"}</div>
          <div className="stat-label">Pending land disputes</div>
        </div>
        <div className="stat-card">
          <div className="stat-value">
            {summary ? `$${summary.revenueThisMonth.total.toFixed(2)}` : "—"}
          </div>
          <div className="stat-label">Revenue this month</div>
        </div>
        <div className="stat-card stat-card-warning">
          <div className="stat-value">{summary?.publicWorksNeedingAttention ?? "—"}</div>
          <div className="stat-label">Public works needing attention</div>
        </div>
      </div>

      <h2>Recent cases</h2>
      <ul className="list">
        {(summary?.recentCases || []).map((c: any) => (
          <li key={c.case_id}>
            <Link to={`/cases/${c.case_id}`}>
              {c.type} — {c.status} — filed {c.filed_date}
            </Link>
          </li>
        ))}
      </ul>
    </div>
  );
}
