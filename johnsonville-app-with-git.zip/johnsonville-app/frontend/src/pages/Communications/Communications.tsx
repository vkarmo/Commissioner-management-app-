import React, { useEffect, useState } from "react";
import { fetchList, createRecord } from "../../api/client";

export default function Communications() {
  const [logs, setLogs] = useState<any[]>([]);
  const [subject, setSubject] = useState("");
  const [linkedOffice, setLinkedOffice] = useState("");
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const [notes, setNotes] = useState("");
  const [submitting, setSubmitting] = useState(false);

  const load = () => fetchList("/communications", "CommunicationLog", "logs").then((r) => setLogs(r.items));
  useEffect(load, []);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    await createRecord(
      "/communications",
      "CommunicationLog",
      { subject, linked_office: linkedOffice, from, to, notes },
      "comm_id"
    );
    setSubject("");
    setNotes("");
    setSubmitting(false);
    load();
  };

  return (
    <div>
      <h1>Communications Log</h1>

      <form className="form" onSubmit={submit}>
        <label>
          Subject
          <input value={subject} onChange={(e) => setSubject(e.target.value)} required />
        </label>
        <label>
          Linked office (Superintendent / County / Ministry)
          <input value={linkedOffice} onChange={(e) => setLinkedOffice(e.target.value)} />
        </label>
        <div className="form-row">
          <label>
            From
            <input value={from} onChange={(e) => setFrom(e.target.value)} />
          </label>
          <label>
            To
            <input value={to} onChange={(e) => setTo(e.target.value)} />
          </label>
        </div>
        <label>
          Notes
          <textarea value={notes} onChange={(e) => setNotes(e.target.value)} rows={3} />
        </label>
        <button type="submit" className="btn btn-primary" disabled={submitting}>
          Log correspondence
        </button>
      </form>

      <ul className="list">
        {logs.map((l) => (
          <li key={l.comm_id}>
            <strong>{l.subject}</strong> — {l.date} — {l.linked_office || "—"}
            {l.notes && <div className="list-item-meta">{l.notes}</div>}
          </li>
        ))}
      </ul>
    </div>
  );
}
