import React, { useEffect, useState } from "react";
import { fetchList, createRecord, request } from "../../api/client";

export default function Registry() {
  const [quarters, setQuarters] = useState<any[]>([]);
  const [persons, setPersons] = useState<any[]>([]);
  const [search, setSearch] = useState("");

  const [newPersonName, setNewPersonName] = useState("");
  const [newPersonPhone, setNewPersonPhone] = useState("");
  const [newPersonQuarter, setNewPersonQuarter] = useState("");

  const loadQuarters = () => request("/registry/quarters").then((d) => setQuarters(d.quarters)).catch(() => {});
  const loadPersons = () => {
    const params = new URLSearchParams();
    if (search) params.set("search", search);
    fetchList(`/registry/persons?${params.toString()}`, "Person", "persons").then((r) => setPersons(r.items));
  };

  useEffect(loadQuarters, []);
  useEffect(loadPersons, [search]);

  const addPerson = async (e: React.FormEvent) => {
    e.preventDefault();
    await createRecord(
      "/registry/persons",
      "Person",
      { name: newPersonName, phone: newPersonPhone, quarter: newPersonQuarter || undefined, role: "citizen" },
      "person_id"
    );
    setNewPersonName("");
    setNewPersonPhone("");
    loadPersons();
  };

  return (
    <div>
      <h1>Community Registry</h1>

      <h2>Quarters &amp; Chiefs</h2>
      <ul className="list">
        {quarters.map((q) => (
          <li key={q.quarter_id}>
            <strong>{q.name}</strong> — pop. {q.population ?? "unknown"} — chief:{" "}
            {q.chief_name || "unassigned"} {q.chief_phone && `(${q.chief_phone})`}
          </li>
        ))}
      </ul>

      <h2>Household / Person Directory</h2>
      <input
        className="search-input"
        placeholder="Search name or phone"
        value={search}
        onChange={(e) => setSearch(e.target.value)}
      />
      <ul className="list">
        {persons.map((p) => (
          <li key={p.person_id}>
            {p.name} {p.phone && `— ${p.phone}`} {p.quarter && `· ${p.quarter}`}
          </li>
        ))}
      </ul>

      <h3>Add person</h3>
      <form className="form form-inline" onSubmit={addPerson}>
        <input placeholder="Name" value={newPersonName} onChange={(e) => setNewPersonName(e.target.value)} required />
        <input placeholder="Phone" value={newPersonPhone} onChange={(e) => setNewPersonPhone(e.target.value)} />
        <select value={newPersonQuarter} onChange={(e) => setNewPersonQuarter(e.target.value)}>
          <option value="">Quarter</option>
          {quarters.map((q) => (
            <option key={q.quarter_id} value={q.quarter_id}>
              {q.name}
            </option>
          ))}
        </select>
        <button type="submit" className="btn btn-primary">
          Add
        </button>
      </form>
    </div>
  );
}
