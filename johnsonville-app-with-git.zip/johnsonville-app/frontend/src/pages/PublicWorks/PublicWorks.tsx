import React, { useEffect, useState } from "react";
import { fetchList, createRecord, request } from "../../api/client";
import { compressPhoto } from "../../utils/compressPhoto";

const CONDITIONS = ["good", "fair", "poor", "critical", "non_functional"];
const TYPES = ["road", "water_point", "school", "clinic"];

export default function PublicWorks() {
  const [items, setItems] = useState<any[]>([]);
  const [needsAttentionOnly, setNeedsAttentionOnly] = useState(false);
  const [fromCache, setFromCache] = useState(false);
  const [quarters, setQuarters] = useState<any[]>([]);

  const [type, setType] = useState("road");
  const [condition, setCondition] = useState("fair");
  const [quarterId, setQuarterId] = useState("");
  const [notes, setNotes] = useState("");
  const [photoRef, setPhotoRef] = useState<string | null>(null);
  const [gps, setGps] = useState<{ lat: number; lng: number } | null>(null);
  const [submitting, setSubmitting] = useState(false);

  const load = () => {
    fetchList(
      `/public-works?${needsAttentionOnly ? "needsAttention=true" : ""}`,
      "PublicWorksItem",
      "items"
    ).then((r) => {
      setItems(r.items);
      setFromCache(r.fromCache);
    });
    request("/registry/quarters").then((d) => setQuarters(d.quarters)).catch(() => {});
  };

  useEffect(load, [needsAttentionOnly]);

  const captureGps = () => {
    if (!navigator.geolocation) return;
    navigator.geolocation.getCurrentPosition(
      (pos) => setGps({ lat: pos.coords.latitude, lng: pos.coords.longitude }),
      () => setGps(null)
    );
  };

  const handlePhoto = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const compressed = await compressPhoto(file);
    setPhotoRef(compressed);
  };

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    await createRecord(
      "/public-works",
      "PublicWorksItem",
      {
        type,
        condition,
        quarter_id: quarterId || undefined,
        notes,
        photo_ref: photoRef,
        gps_lat: gps?.lat,
        gps_lng: gps?.lng,
      },
      "public_works_id"
    );
    setNotes("");
    setPhotoRef(null);
    setSubmitting(false);
    load();
  };

  return (
    <div>
      <h1>Public Works Tracker</h1>
      {fromCache && <div className="alert alert-warning">Showing cached results — offline.</div>}

      <h2>Log an item</h2>
      <form className="form" onSubmit={submit}>
        <label>
          Type
          <select value={type} onChange={(e) => setType(e.target.value)}>
            {TYPES.map((t) => (
              <option key={t} value={t}>
                {t.replace("_", " ")}
              </option>
            ))}
          </select>
        </label>
        <label>
          Condition
          <select value={condition} onChange={(e) => setCondition(e.target.value)}>
            {CONDITIONS.map((c) => (
              <option key={c} value={c}>
                {c.replace("_", " ")}
              </option>
            ))}
          </select>
        </label>
        <label>
          Quarter
          <select value={quarterId} onChange={(e) => setQuarterId(e.target.value)}>
            <option value="">Select quarter</option>
            {quarters.map((q) => (
              <option key={q.quarter_id} value={q.quarter_id}>
                {q.name}
              </option>
            ))}
          </select>
        </label>
        <label>
          Notes
          <textarea value={notes} onChange={(e) => setNotes(e.target.value)} rows={3} />
        </label>
        <button type="button" className="btn" onClick={captureGps}>
          {gps ? `GPS: ${gps.lat.toFixed(4)}, ${gps.lng.toFixed(4)}` : "Capture GPS location"}
        </button>
        <label>
          Photo (optional)
          <input type="file" accept="image/*" capture="environment" onChange={handlePhoto} />
        </label>
        {photoRef && <img src={photoRef} alt="preview" className="photo-preview" />}
        <button type="submit" className="btn btn-primary btn-large" disabled={submitting}>
          {submitting ? "Saving…" : "Log Item"}
        </button>
      </form>

      <div className="page-header">
        <h2>Items</h2>
        <label className="checkbox-label">
          <input
            type="checkbox"
            checked={needsAttentionOnly}
            onChange={(e) => setNeedsAttentionOnly(e.target.checked)}
          />
          Needs attention only
        </label>
      </div>
      <ul className="list">
        {items.map((it) => (
          <li key={it.public_works_id} className="list-item">
            <span className={`badge badge-${it.condition}`}>{it.condition?.replace("_", " ")}</span>
            <strong>{it.type?.replace("_", " ")}</strong> — {it.quarter_name || "—"}
            {it.notes && <div className="list-item-meta">{it.notes}</div>}
          </li>
        ))}
        {items.length === 0 && <li>No items found.</li>}
      </ul>
    </div>
  );
}
