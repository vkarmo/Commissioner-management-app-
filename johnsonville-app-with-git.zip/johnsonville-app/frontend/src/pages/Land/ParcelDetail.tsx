import React, { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import { request } from "../../api/client";
import ParcelMap from "../../components/ParcelMap";

function parseGeometry(raw: any): any | null {
  if (!raw) return null;
  if (typeof raw === "object") return raw;
  try {
    return JSON.parse(raw);
  } catch {
    return null;
  }
}

export default function ParcelDetail() {
  const { id } = useParams<{ id: string }>();
  const [data, setData] = useState<any>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!id) return;
    request(`/land/parcels/${id}`)
      .then(setData)
      .catch(() => setError("Couldn't load full parcel detail — you may be offline."));
  }, [id]);

  if (!data) return <div>{error || "Loading…"}</div>;

  const { parcel, quarter_name, deeds, adjacent_parcels, disputes } = data;
  const geometry = parseGeometry(parcel.geometry);
  const adjacentWithGeometry = (adjacent_parcels || [])
    .filter((a: any) => a.parcel_id)
    .map((a: any) => ({ parcel_id: a.parcel_id, geometry: parseGeometry(a.geometry) }));

  return (
    <div>
      <h1>Parcel {parcel.parcel_id.slice(0, 8)}…</h1>
      {error && <div className="alert alert-warning">{error}</div>}

      {disputes && disputes.length > 0 && (
        <div className="alert alert-error">
          This parcel is currently subject to {disputes.length} open dispute(s).
        </div>
      )}

      <div className="detail-grid">
        <div>
          <strong>Quarter:</strong> {quarter_name || "—"}
        </div>
        <div>
          <strong>Land use:</strong> {parcel.land_use || "—"}
        </div>
        <div>
          <strong>Acreage:</strong> {parcel.acreage || "—"}
        </div>
      </div>

      <h3>Boundary map</h3>
      <ParcelMap geometry={geometry} parcelId={parcel.parcel_id} adjacent={adjacentWithGeometry} />

      <h3>Deed history</h3>
      <ul className="list">
        {deeds.map((d: any, i: number) => (
          <li key={i}>
            {d.deed.properties.deed_number || "No deed number"} — {d.deed.properties.type}, issued{" "}
            {d.deed.properties.issue_date} — owner: {d.owner}
          </li>
        ))}
        {deeds.length === 0 && <li>No deed on record.</li>}
      </ul>

      <h3>Adjacent parcels</h3>
      <ul className="list">
        {adjacent_parcels.map((a: any) => (
          <li key={a.parcel_id}>
            <Link to={`/land/parcels/${a.parcel_id}`}>{a.parcel_id.slice(0, 8)}…</Link> — {a.land_use}
          </li>
        ))}
        {adjacent_parcels.length === 0 && <li>No adjacency recorded.</li>}
      </ul>
    </div>
  );
}
