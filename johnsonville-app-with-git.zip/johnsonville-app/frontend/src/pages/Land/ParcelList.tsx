import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { fetchList } from "../../api/client";

export default function ParcelList() {
  const [parcels, setParcels] = useState<any[]>([]);
  const [search, setSearch] = useState("");
  const [fromCache, setFromCache] = useState(false);

  const load = () => {
    const params = new URLSearchParams();
    if (search) params.set("search", search);
    fetchList(`/land/parcels?${params.toString()}`, "Parcel", "parcels").then((r) => {
      setParcels(r.items);
      setFromCache(r.fromCache);
    });
  };

  useEffect(load, [search]);

  return (
    <div>
      <div className="page-header">
        <h1>Land Records</h1>
        <Link to="/land/new" className="btn btn-primary">
          + Register parcel
        </Link>
      </div>

      {fromCache && (
        <div className="alert alert-warning">Showing cached results — you appear to be offline.</div>
      )}

      <input
        className="search-input"
        placeholder="Search by parcel ID or owner name"
        value={search}
        onChange={(e) => setSearch(e.target.value)}
      />

      <ul className="list">
        {parcels.map((p) => (
          <li key={p.parcel_id} className="list-item">
            <Link to={`/land/parcels/${p.parcel_id}`}>
              {p.has_open_dispute && <span className="badge badge-dispute">DISPUTE</span>}
              <strong>{p.parcel_id.slice(0, 8)}…</strong> — {p.land_use || "unspecified use"}, {p.acreage || "?"} acres
              <div className="list-item-meta">
                {p.quarter_name || "Unassigned quarter"} · owner: {(p.owners || []).filter(Boolean).join(", ") || "unknown"}
              </div>
            </Link>
          </li>
        ))}
        {parcels.length === 0 && <li>No parcels found.</li>}
      </ul>
    </div>
  );
}
