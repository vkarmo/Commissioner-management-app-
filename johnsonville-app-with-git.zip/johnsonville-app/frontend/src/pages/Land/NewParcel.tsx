import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { createRecord, request } from "../../api/client";

export default function NewParcel() {
  const navigate = useNavigate();
  const [quarters, setQuarters] = useState<any[]>([]);
  const [acreage, setAcreage] = useState("");
  const [landUse, setLandUse] = useState("residential");
  const [quarterId, setQuarterId] = useState("");
  const [geometryText, setGeometryText] = useState("");
  const [geometryError, setGeometryError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    request("/registry/quarters").then((d) => setQuarters(d.quarters)).catch(() => setQuarters([]));
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setGeometryError(null);

    let geometry: any = undefined;
    if (geometryText.trim()) {
      try {
        geometry = JSON.parse(geometryText);
      } catch {
        setGeometryError("That doesn't look like valid GeoJSON. Leave blank if you don't have boundary coordinates yet.");
        return;
      }
    }

    setSubmitting(true);
    const parcelId = await createRecord(
      "/land/parcels",
      "Parcel",
      { acreage: parseFloat(acreage) || null, land_use: landUse, quarter_id: quarterId || undefined, geometry },
      "parcel_id"
    );
    setSubmitting(false);
    navigate(navigator.onLine ? `/land/parcels/${parcelId}` : "/land");
  };

  return (
    <div>
      <h1>Register Parcel</h1>
      <form className="form" onSubmit={handleSubmit}>
        <label>
          Land use
          <select value={landUse} onChange={(e) => setLandUse(e.target.value)}>
            <option value="residential">Residential</option>
            <option value="agricultural">Agricultural</option>
            <option value="commercial">Commercial</option>
            <option value="public">Public</option>
          </select>
        </label>
        <label>
          Acreage
          <input type="number" step="0.01" value={acreage} onChange={(e) => setAcreage(e.target.value)} />
        </label>
        <label>
          Quarter
          <select value={quarterId} onChange={(e) => setQuarterId(e.target.value)}>
            <option value="">Select quarter</option>
            {quarters.map((q) => (
              <option key={q.quarter_id} value={q.quarter_id}>
                {q.name}
              </option>
            ))}
          </select>
        </label>
        <label>
          Boundary geometry (GeoJSON, optional)
          <textarea
            value={geometryText}
            onChange={(e) => setGeometryText(e.target.value)}
            rows={4}
            placeholder='{"type":"Polygon","coordinates":[[[-10.797,6.328],[-10.796,6.328],[-10.796,6.327],[-10.797,6.327],[-10.797,6.328]]]}'
          />
        </label>
        {geometryError && <div className="alert alert-warning">{geometryError}</div>}
        <p className="fineprint">
          Leave blank if you don't have surveyed boundary coordinates yet — you can add them later. When
          present, this renders as a map on the parcel's detail page.
        </p>
        <button type="submit" className="btn btn-primary btn-large" disabled={submitting}>
          {submitting ? "Saving…" : "Register Parcel"}
        </button>
      </form>
    </div>
  );
}
