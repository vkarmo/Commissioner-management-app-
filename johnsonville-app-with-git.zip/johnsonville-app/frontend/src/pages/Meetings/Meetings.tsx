import React, { useEffect, useState } from "react";
import { fetchList, createRecord, request } from "../../api/client";

export default function Meetings() {
  const [meetings, setMeetings] = useState<any[]>([]);
  const [quarters, setQuarters] = useState<any[]>([]);
  const [date, setDate] = useState("");
  const [location, setLocation] = useState("");
  const [quarterId, setQuarterId] = useState("");
  const [attendees, setAttendees] = useState("");
  const [summary, setSummary] = useState("");
  const [submitting, setSubmitting] = useState(false);

  const load = () => fetchList("/meetings", "Meeting", "meetings").then((r) => setMeetings(r.items));
  useEffect(load, []);
  useEffect(() => {
    request("/registry/quarters").then((d) => setQuarters(d.quarters)).catch(() => {});
  }, []);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    await createRecord(
      "/meetings",
      "Meeting",
      {
        date,
        location,
        quarter_id: quarterId || undefined,
        attendees: attendees.split(",").map((a) => a.trim()).filter(Boolean),
        summary,
      },
      "meeting_id"
    );
    setSummary("");
    setAttendees("");
    setSubmitting(false);
    load();
  };

  return (
    <div>
      <h1>Meetings / Palava Hut Records</h1>

      <form className="form" onSubmit={submit}>
        <div className="form-row">
          <label>
            Date
            <input type="date" value={date} onChange={(e) => setDate(e.target.value)} required />
          </label>
          <label>
            Location
            <input value={location} onChange={(e) => setLocation(e.target.value)} />
          </label>
        </div>
        <label>
          Quarter
          <select value={quarterId} onChange={(e) => setQuarterId(e.target.value)}>
            <option value="">Select quarter</option>
            {quarters.map((q) => (
              <option key={q.quarter_id} value={q.quarter_id}>
                {q.name}
              </option>
            ))}
          </select>
        </label>
        <label>
          Attendees (comma separated)
          <input value={attendees} onChange={(e) => setAttendees(e.target.value)} />
        </label>
        <label>
          Minutes / resolution notes
          <textarea value={summary} onChange={(e) => setSummary(e.target.value)} rows={4} />
        </label>
        <button type="submit" className="btn btn-primary" disabled={submitting}>
          Log meeting
        </button>
      </form>

      <ul className="list">
        {meetings.map((m) => (
          <li key={m.meeting_id}>
            <strong>{m.date}</strong> — {m.location || "—"} — {m.quarter_name || "—"}
            {m.summary && <div className="list-item-meta">{m.summary}</div>}
          </li>
        ))}
      </ul>
    </div>
  );
}
