import React from "react";
import ReactDOM from "react-dom/client";
import App from "./App";
import { initSyncEngine } from "./db/syncEngine";
import "./styles.css";

initSyncEngine();

ReactDOM.createRoot(document.getElementById("root")!).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
